package remax.grupo3;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClienteDAO {
  
    //GUARDAR
    public void insertar(Cliente cliente){
        
        String consulta_sql = "INSERT INTO Cliente(nombre,apellido,dni,telefono,email,contraseña,recibo_sueldo,mascotas,hijos)VALUES(?,?,?,?,?,?,?,?,?)";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1,cliente.getNombre() );
            sentencia_sql.setString(2,cliente.getApellido() );
            sentencia_sql.setInt(3,cliente.getDni() );
            sentencia_sql.setString(1,cliente.getTelefono() );
            sentencia_sql.setString(1,cliente.getEmail() );
            sentencia_sql.setString(1,cliente.getContraseña() );
            sentencia_sql.setBoolean(1,cliente.isRecibo_sueldo() );
            sentencia_sql.setBoolean(1,cliente.isMascotas() );
            sentencia_sql.setBoolean(1,cliente.isHijos() );
            
            sentencia_sql.executeUpdate();
                   
            System.out.println("Cliente guardado exitosamemente");

        }catch(SQLException ex){
             System.out.println("ERROR: "+ex.getMessage());   
        }
    }  
        
     //MOSTRAR
     
    public ArrayList <Cliente> listar(){
         ArrayList <Cliente> lista_clientes = new ArrayList<>();
         
         String consulta_sql ="SELECT * FROM Cliente";
         
         try{
             Connection conexion = Conexion.conectar();
             PreparedStatement sentencia_sql= conexion.prepareStatement(consulta_sql);
             
             ResultSet resultado = sentencia_sql.executeQuery();
             
             while(resultado.next()){
                 Cliente cliente = new Cliente();
                 
                 cliente.setId(resultado.getInt("id"));
                 cliente.setNombre(resultado.getString("nombre"));
                 cliente.setApellido(resultado.getString("apellido"));
                 cliente.setDni(resultado.getInt("dni"));
                 cliente.setTelefono(resultado.getString("telefono"));
                 cliente.setEmail(resultado.getString("Email"));
                 cliente.setContraseña(resultado.getString("contraseña"));
                 cliente.setRecibo_sueldo(resultado.getBoolean("recibo_sueldo"));
                 cliente.setMascotas(resultado.getBoolean("mascotas"));
                 cliente.setHijos(resultado.getBoolean("hijos"));
                 
             }
         }catch(SQLException ex){
             System.out.println("ERROR: "+ ex.getMessage());
         }
         return lista_clientes;
    }

    
    //EDITAR
    
    public void actualizar (Cliente cliente){
        String consulta_sql ="UPDATE Cliente SET nombre=?,apellido=?,dni=?,telefono=? email=?,contraseña=? recibo_sueldo=?,mascotas=? hijos=?  WHERE id=?";

        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql =conexion.prepareStatement(consulta_sql);
            
         
            
            sentencia_sql.setString(1, cliente.getNombre());
            sentencia_sql.setString(2, cliente.getApellido());
            sentencia_sql.setInt(3, cliente.getDni());
            sentencia_sql.setString(4, cliente.getTelefono());
            sentencia_sql.setString(5, cliente.getEmail());
            sentencia_sql.setString(6, cliente.getContraseña());
            sentencia_sql.setBoolean(7, cliente.isRecibo_sueldo());
            sentencia_sql.setBoolean(8, cliente.isMascotas());
            sentencia_sql.setBoolean(9, cliente.isHijos());
         
            sentencia_sql.executeUpdate();
            
            System.out.println("Datos actualizados correctamente.");
        }catch(SQLException ex){
            System.out.println("ERROR: "+ ex.getMessage());
        }
    }
    
    
    //ELIMINAR
    
    public void eliminar(int id){
        String consulta_sql ="DELETE FROM Cliente WHERE id=?";
        try{
            
            Connection conexion =Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
            System.out.println("Registro eliminado");

        }catch(SQLException ex){
            System.out.println("ERROR: "+ex.getMessage());
        }
    }
}

