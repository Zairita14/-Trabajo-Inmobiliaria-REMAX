
package remax.grupo3;

import javax.swing.JOptionPane;

public class RemaxGrupo3 {
    
    public static void main(String[] args) {
        
       
Conexion conexion = new Conexion();
    if (conexion !=null) {
        System.out.println("Conexion exitosa");
            }else{
            System.out.println("ERROR DE CONEXION");
    }
        
        
    VentanaIngreso ventana = new VentanaIngreso();
   
    ventana.setLocationRelativeTo(null);
    ventana.setVisible(true);
        
    
    
    
    
    
    
    
        
        
        
               
    }
    
}
