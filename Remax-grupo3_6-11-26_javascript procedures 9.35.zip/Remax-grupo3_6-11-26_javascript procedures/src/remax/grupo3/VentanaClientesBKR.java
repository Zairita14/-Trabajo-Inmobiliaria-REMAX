package remax.grupo3;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class VentanaClientesBKR extends javax.swing.JFrame {

    public VentanaClientesBKR() {
        initComponents();
    }

   private void limpiar(){
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtEmail.setText("");
        txtContraseña.setText("");
        chkRecibo_sueldoSi.setSelected(false);
        chkMascotasSi.setSelected(false);
        chkHijosSi.setSelected(false);
        chkRecibo_sueldoNo.setSelected(false);
        chkMascotasNo.setSelected(false);
        chkHijosNo.setSelected(false);
           
    }
    
    private void mostrarTabla(){
          ClienteDAO dao = new ClienteDAO();
        ArrayList<Cliente>lista_clientes=dao.listar();
        DefaultTableModel modelo=(DefaultTableModel)TablaClientes.getModel();
        
        modelo.setRowCount(0);
        for (Cliente c:lista_clientes) {
           modelo.addRow(new Object[]{
            c.getId(),
            c.getNombre(),
            c.getApellido(),
            c.getDni(),
            c.getTelefono(),
            c.getEmail(),
            c.getContraseña(),
            c.isRecibo_sueldo(),
            c.isMascotas(),
            c.isHijos(),
              
        });     
        }

    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaClientes = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtContraseña = new javax.swing.JTextField();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        chkRecibo_sueldoSi = new javax.swing.JCheckBox();
        chkMascotasSi = new javax.swing.JCheckBox();
        chkHijosSi = new javax.swing.JCheckBox();
        chkRecibo_sueldoNo = new javax.swing.JCheckBox();
        chkMascotasNo = new javax.swing.JCheckBox();
        chkHijosNo = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(30, 117, 20));

        TablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellido", "DNI", "Telefono", "Email", "Contraseña", "¿Recibo sueldo?", "¿Mascotas?", "¿Hijos?"
            }
        ));
        TablaClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaClientes);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nombre");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Apellido");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("DNI");

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Telefono");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Email");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Contraseña");

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("¿Tenes recibo de sueldo?");

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("¿Tenes hijos?");

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("¿Tenes macotas?");

        btnGuardar.setText("AGREGAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });

        txtDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDniActionPerformed(evt);
            }
        });

        btnMostrar.setText("MOSTRAR");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("DNI");

        jLabel11.setFont(new java.awt.Font("Tw Cen MT", 0, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Clientes");

        chkRecibo_sueldoSi.setBackground(new java.awt.Color(30, 117, 20));
        buttonGroup1.add(chkRecibo_sueldoSi);
        chkRecibo_sueldoSi.setForeground(new java.awt.Color(255, 255, 255));
        chkRecibo_sueldoSi.setText("Si");
        chkRecibo_sueldoSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkRecibo_sueldoSiActionPerformed(evt);
            }
        });

        chkMascotasSi.setBackground(new java.awt.Color(30, 117, 20));
        buttonGroup2.add(chkMascotasSi);
        chkMascotasSi.setForeground(new java.awt.Color(255, 255, 255));
        chkMascotasSi.setText("Si");
        chkMascotasSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkMascotasSiActionPerformed(evt);
            }
        });

        chkHijosSi.setBackground(new java.awt.Color(30, 117, 20));
        buttonGroup3.add(chkHijosSi);
        chkHijosSi.setForeground(new java.awt.Color(255, 255, 255));
        chkHijosSi.setText("Si");
        chkHijosSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHijosSiActionPerformed(evt);
            }
        });

        chkRecibo_sueldoNo.setBackground(new java.awt.Color(30, 117, 20));
        buttonGroup1.add(chkRecibo_sueldoNo);
        chkRecibo_sueldoNo.setForeground(new java.awt.Color(255, 255, 255));
        chkRecibo_sueldoNo.setText("No");

        chkMascotasNo.setBackground(new java.awt.Color(30, 117, 20));
        buttonGroup2.add(chkMascotasNo);
        chkMascotasNo.setForeground(new java.awt.Color(255, 255, 255));
        chkMascotasNo.setText("No");

        chkHijosNo.setBackground(new java.awt.Color(30, 117, 20));
        buttonGroup3.add(chkHijosNo);
        chkHijosNo.setForeground(new java.awt.Color(255, 255, 255));
        chkHijosNo.setText("No");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addComponent(jLabel9)
                            .addComponent(btnVolver))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(chkRecibo_sueldoSi)
                            .addComponent(chkMascotasSi)
                            .addComponent(chkHijosSi))
                        .addGap(41, 41, 41)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(chkMascotasNo)
                            .addComponent(chkRecibo_sueldoNo)
                            .addComponent(chkHijosNo)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtDni, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtApellido, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmail)
                            .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscar))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(btnGuardar)
                            .addGap(106, 106, 106)
                            .addComponent(btnMostrar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnEditar)
                            .addGap(86, 86, 86)
                            .addComponent(btnEliminar))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 604, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 25, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(30, Short.MAX_VALUE)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(chkRecibo_sueldoSi)
                            .addComponent(chkRecibo_sueldoNo))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(chkMascotasSi)
                            .addComponent(chkMascotasNo))
                        .addGap(16, 16, 16)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(chkHijosSi)
                            .addComponent(chkHijosNo)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBuscar)
                            .addComponent(jLabel10)
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnMostrar)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEditar)
                            .addComponent(btnEliminar))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
   
     String nombre = txtNombre.getText();
   String apellido = txtApellido.getText();
   String dni = txtDni.getText();
   String telefono = txtTelefono.getText();
   String email = txtEmail.getText();
   String contraseña = txtContraseña.getText();
   boolean recibo_sueldoNew = chkRecibo_sueldoSi.isSelected();
   boolean mascotasNew = chkMascotasSi.isSelected();
   boolean hijosNew = chkHijosSi.isSelected();
   
   if ((nombre.length() < 1) || (apellido.length() < 1) || (dni.length() < 1) ||  (telefono.length() < 1) || (email.length() < 1)||  (contraseña.length() < 1)){
        JOptionPane.showMessageDialog(null, "ERROR: Hay campos vacios");
        return;
    }
    
   if(!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
        JOptionPane.showMessageDialog(null, "ERROR: El campo nombre solo puede contener letras");
        return;
    }
     
   if(!apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
        JOptionPane.showMessageDialog(null, "ERROR: El campo apellido solo puede contener letras");
        return;
   }
   
   if(dni.length() != 8){
        JOptionPane.showMessageDialog(null, "ERROR: El DNI debe tener exactamente 8 digitos. Sin puntos");
        
          return; 
   }
      
     
   if(telefono.length() != 10){
       JOptionPane.showMessageDialog(null,"ERROR: EL TELEFONO DEBE TENER EXACTAMENTE 10 DIGITOS. Sin espacios");
       return;
   }
    
   if(!email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")){
        JOptionPane.showMessageDialog(null, "ERROR: Ingrese un email valido!");
        return;
   }


   int dniNew = Integer.parseInt(dni);
     
 
   Cliente cliente_nuevo = new Cliente();
   
   cliente_nuevo.setNombre(nombre);
   cliente_nuevo.setApellido(apellido);
   cliente_nuevo.setDni(dniNew);
   cliente_nuevo.setTelefono(telefono);
   cliente_nuevo.setEmail(email);
   cliente_nuevo.setContraseña(contraseña);
   cliente_nuevo.setRecibo_sueldo(recibo_sueldoNew);
   cliente_nuevo.setMascotas(mascotasNew);
   cliente_nuevo.setHijos(hijosNew);

   ClienteDAO dao = new ClienteDAO();
   dao.insertar(cliente_nuevo);
   
   limpiar();
   mostrarTabla();
  

          
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
  int fila = TablaClientes.getSelectedRow();

            if (fila == -1) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un cliente.");
                return;
            }
            int id = (int) TablaClientes.getValueAt(fila, 0);
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();         
            int  dni = Integer.parseInt(txtDni.getText());
            String telefono = txtTelefono.getText();
            String email = txtEmail.getText();
            String contraseña = txtContraseña.getText();
            

            Cliente clientee = new Cliente();
            clientee.setId(id);
            clientee.setNombre(nombre);
            clientee.setApellido(apellido);
            clientee.setDni(dni);
            clientee.setTelefono(telefono);
            clientee.setEmail(email);
            clientee.setContraseña(contraseña);
            clientee.setRecibo_sueldo(chkRecibo_sueldoSi.isSelected());
            clientee.setMascotas(chkMascotasSi.isSelected());
            clientee.setHijos(chkHijosSi.isSelected());

            ClienteDAO dao = new ClienteDAO();
            dao.actualizar(clientee);
            mostrarTabla();
              
            
           
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
       int fila= TablaClientes.getSelectedRow();
        if(fila == -1){
            JOptionPane.showMessageDialog(null, "Debe seleccionar un cliente.");
            return;
        }
          int respuesta = JOptionPane.showConfirmDialog( null, "¿Estás seguro de que querés eliminar este cliente?",  "",JOptionPane.YES_NO_OPTION);
           
        if (respuesta == JOptionPane.YES_OPTION) {   
        int id_cliente=(int)TablaClientes.getValueAt(fila,0);
        ClienteDAO dao= new ClienteDAO();
        dao.eliminar(id_cliente);
       
        mostrarTabla();
        limpiar();
        }else{
            JOptionPane.showMessageDialog(null,"No se ha eliminado ningun Cliente");
        }
        
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
     VentanaOpcionesBroker ventanaOpciones = new VentanaOpcionesBroker();
     ventanaOpciones.setVisible(true);

    // Cerramos y destruimos la ventana actual de clientes para liberar memoria
    this.dispose();
    
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
            mostrarTabla();
        
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void TablaClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaClientesMouseClicked
    
        int fila = TablaClientes.getSelectedRow();
        
        int id = (int) TablaClientes.getValueAt(fila,0);
        
        String nombre = TablaClientes.getValueAt(fila,1).toString();
        String apellido = TablaClientes.getValueAt(fila,2).toString();
        String dni = TablaClientes.getValueAt(fila,3).toString();
        String telefono = TablaClientes.getValueAt(fila,4).toString();
        String email = TablaClientes.getValueAt(fila,5).toString();
        String contraseña = TablaClientes.getValueAt(fila,6).toString();
        boolean recibo_sueldo = Boolean.parseBoolean(TablaClientes.getValueAt(fila, 7).toString());
        boolean mascotas = Boolean.parseBoolean(TablaClientes.getValueAt(fila, 8).toString());
        boolean hijos = Boolean.parseBoolean(TablaClientes.getValueAt(fila, 9).toString());
        
        
        
        /*/
        boolean mascotas = (boolean) TablaClientes.getValueAt(fila, 8);
        boolean hijos = (boolean) TablaClientes.getValueAt(fila, 9);
/*/
        txtNombre.setText(nombre);
        txtApellido.setText(apellido);
        txtDni.setText(dni);
        txtTelefono.setText(telefono);
        txtEmail.setText(email);
        txtContraseña.setText(contraseña);
        chkRecibo_sueldoSi.setSelected(recibo_sueldo);
        chkRecibo_sueldoNo.setSelected(!recibo_sueldo);
        chkMascotasSi.setSelected(mascotas);
        chkMascotasNo.setSelected(!mascotas);
        chkHijosSi.setSelected(hijos);
        chkHijosNo.setSelected(!hijos);
        
        
        System.out.println("ID seleccionado: "+ id);
    

    }//GEN-LAST:event_TablaClientesMouseClicked

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
     
 
    if (txtBuscar.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Por favor ingrese un DNI");
        return;
    }
    
    int dni = Integer.parseInt(txtBuscar.getText());
    ClienteDAO dao = new ClienteDAO();
    ArrayList<Cliente> lista_clientes = dao.buscarPorDni(dni);
    DefaultTableModel modelo = (DefaultTableModel) TablaClientes.getModel();
    modelo.setRowCount(0);
    
    for (Cliente c : lista_clientes) {
        modelo.addRow(new Object[]{
            c.getId(),
            c.getNombre(),
            c.getApellido(),
            c.getDni(),
            c.getTelefono(),
            c.getEmail(),
            c.getContraseña(),
            c.isRecibo_sueldo(),
            c.isMascotas(),
            c.isHijos()
        });
     }
         
    }//GEN-LAST:event_btnBuscarActionPerformed

    
    private void txtDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDniActionPerformed

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void chkRecibo_sueldoSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkRecibo_sueldoSiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkRecibo_sueldoSiActionPerformed

    private void chkMascotasSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkMascotasSiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkMascotasSiActionPerformed

    private void chkHijosSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkHijosSiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkHijosSiActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
   mostrarTabla();
    }//GEN-LAST:event_formComponentShown

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaClientes;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JCheckBox chkHijosNo;
    private javax.swing.JCheckBox chkHijosSi;
    private javax.swing.JCheckBox chkMascotasNo;
    private javax.swing.JCheckBox chkMascotasSi;
    private javax.swing.JCheckBox chkRecibo_sueldoNo;
    private javax.swing.JCheckBox chkRecibo_sueldoSi;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtContraseña;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables

}