
package remax.grupo3;

public class Propiedad {
    private String tipoPropiedad;
    private  String Ubicacion;
    private String Direccion;
    private  int precio;
    private String Descripcion;
    private  double MetrosCuadrados;
   private int Ambiente;
    private  int CantBaños;
    private  int Antiguedad;
    private  int reseña;
    private  int ExpensasMensuales;
    private  int piso;
    private  String letraDep;
   private  boolean incluyeVentana;
     
      private boolean incluyePatio;
       private  boolean incluyeMuebles;
       private  boolean incluyePiscina;
        private  boolean enConstruccion;

    public Propiedad(String tipoPropiedad, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales, int piso, String letraDep, boolean incluyeVentana, boolean incluyePatio, boolean incluyeMuebles, boolean incluyePiscina, boolean enConstruccion) {
        this.tipoPropiedad = tipoPropiedad;
        this.Ubicacion = Ubicacion;
        this.Direccion = Direccion;
        this.precio = precio;
        this.Descripcion = Descripcion;
        this.MetrosCuadrados = MetrosCuadrados;
        this.Ambiente = Ambiente;
        this.CantBaños = CantBaños;
        this.Antiguedad = Antiguedad;
        this.reseña = reseña;
        this.ExpensasMensuales = ExpensasMensuales;
        this.piso = piso;
        this.letraDep = letraDep;
        this.incluyeVentana = incluyeVentana;
        this.incluyePatio = incluyePatio;
        this.incluyeMuebles = incluyeMuebles;
        this.incluyePiscina = incluyePiscina;
        this.enConstruccion = enConstruccion;
    }

    public String getTipoPropiedad() {
        return tipoPropiedad;
    }

    public void setTipoPropiedad(String tipoPropiedad) {
        this.tipoPropiedad = tipoPropiedad;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String Ubicacion) {
        this.Ubicacion = Ubicacion;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public double getMetrosCuadrados() {
        return MetrosCuadrados;
    }

    public void setMetrosCuadrados(double MetrosCuadrados) {
        this.MetrosCuadrados = MetrosCuadrados;
    }

    public int getAmbiente() {
        return Ambiente;
    }

    public void setAmbiente(int Ambiente) {
        this.Ambiente = Ambiente;
    }

    public int getCantBaños() {
        return CantBaños;
    }

    public void setCantBaños(int CantBaños) {
        this.CantBaños = CantBaños;
    }

    public int getAntiguedad() {
        return Antiguedad;
    }

    public void setAntiguedad(int Antiguedad) {
        this.Antiguedad = Antiguedad;
    }

    public int getReseña() {
        return reseña;
    }

    public void setReseña(int reseña) {
        this.reseña = reseña;
    }

    public int getExpensasMensuales() {
        return ExpensasMensuales;
    }

    public void setExpensasMensuales(int ExpensasMensuales) {
        this.ExpensasMensuales = ExpensasMensuales;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public String getLetraDep() {
        return letraDep;
    }

    public void setLetraDep(String letraDep) {
        this.letraDep = letraDep;
    }

    public boolean isIncluyeVentana() {
        return incluyeVentana;
    }

    public void setIncluyeVentana(boolean incluyeVentana) {
        this.incluyeVentana = incluyeVentana;
    }

    public boolean isIncluyePatio() {
        return incluyePatio;
    }

    public void setIncluyePatio(boolean incluyePatio) {
        this.incluyePatio = incluyePatio;
    }

    public boolean isIncluyeMuebles() {
        return incluyeMuebles;
    }

    public void setIncluyeMuebles(boolean incluyeMuebles) {
        this.incluyeMuebles = incluyeMuebles;
    }

    public boolean isIncluyePiscina() {
        return incluyePiscina;
    }

    public void setIncluyePiscina(boolean incluyePiscina) {
        this.incluyePiscina = incluyePiscina;
    }

    public boolean isEnConstruccion() {
        return enConstruccion;
    }

    public void setEnConstruccion(boolean enConstruccion) {
        this.enConstruccion = enConstruccion;
    }
    
    
    
    
}
