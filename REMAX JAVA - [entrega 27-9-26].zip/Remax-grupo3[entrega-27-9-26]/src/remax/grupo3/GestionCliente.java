
package remax.grupo3;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;

public class GestionCliente {
    private ArrayList<Cliente> lista_clientes;

    public GestionCliente() {
       lista_clientes = new ArrayList<>();
    }

   

    public ArrayList<Cliente> getLista_clientes() {
        return lista_clientes;
    }

    public void setLista_clientes(ArrayList<Cliente> lista_clientes) {
        this.lista_clientes = lista_clientes;
    }
    
    public void agregarCliente(Cliente c){
       lista_clientes.add(c);
    }
    
    public Cliente buscarCliente(int dni){
        for(Cliente c: lista_clientes){
            if (c.getDni() == dni){
                return c;
                }    
             
        }
       JOptionPane.showMessageDialog(null, "No se encontro ninguna persona registrada");
       return null;
    }
    
    
        public boolean eliminarCliente(int dni){
            Cliente eliminar = buscarCliente(dni);
            
            if (eliminar != null){
                
                lista_clientes.remove(eliminar);
                return true;
                
                
            }
                  
            
            return false;
            
        }
    
    
    
    
    
    public boolean editarCliente(boolean reciboSueldo, boolean mascotas, boolean hijos, String nombre, String apellido, int dni, int telefono, String email){
        
        
         Cliente editar = buscarCliente(dni);
         
         if (editar != null){
             editar.setNombre(nombre);
             editar.setApellido(apellido);
             editar.setTelefono(telefono);
             editar.setEmail(email);
             editar.setReciboSueldo(reciboSueldo);
             editar.setMascotas(mascotas);
             editar.setHijos(hijos);
             return true;
         }
         
         
     return false;    
    }
    
    
    
    
    
    
    
}