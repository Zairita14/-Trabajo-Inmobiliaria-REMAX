
package remax.grupo3;

public class Operacion {
    private String propiedad;
    private String tipo;
    private int cliente;
    private int agente;
    private String fecha;
    private int plazoalquiler;

    public Operacion(String propiedad, String tipo, int cliente, int agente, String fecha, int plazoalquiler) {
        this.propiedad = propiedad;
        this.tipo = tipo;
        this.cliente = cliente;
        this.agente = agente;
        this.fecha = fecha;
        this.plazoalquiler = plazoalquiler;
    }

    public String getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(String propiedad) {
        this.propiedad = propiedad;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }

    public int getAgente() {
        return agente;
    }

    public void setAgente(int agente) {
        this.agente = agente;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getPlazoalquiler() {
        return plazoalquiler;
    }

    public void setPlazoalquiler(int plazoalquiler) {
        this.plazoalquiler = plazoalquiler;
    }
  
    

    
}

