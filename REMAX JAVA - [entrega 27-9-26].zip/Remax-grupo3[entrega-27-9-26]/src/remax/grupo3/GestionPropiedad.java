
package remax.grupo3;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class GestionPropiedad {
    
      private ArrayList<Propiedad> lista_propiedades;

    public GestionPropiedad() {
       lista_propiedades = new ArrayList<>();
    }

    public ArrayList<Propiedad> getLista_propiedades() {
        return lista_propiedades;
    }

    public void setLista_propiedades(ArrayList<Propiedad> lista_propiedades) {
        this.lista_propiedades = lista_propiedades;
    }

   

    public void agregarPropiedad(Propiedad p){
       lista_propiedades.add(p);
    }
    
    public Propiedad buscarPropiedad(String direccion){
        for(Propiedad p: lista_propiedades){
            if (p.getDireccion().equals(direccion)){
                return p;
                }    
             
        }
       JOptionPane.showMessageDialog(null, "No se encontro ninguna propiedad registrada");
       return null;
    }
    
    
        public boolean eliminarPropiedad(String direccion){
            Propiedad eliminar = buscarPropiedad(direccion);
            
            if (eliminar != null){
                
                lista_propiedades.remove(eliminar);
                return true;
                
                
            }
                  
            
            return false;
            
        }
    
    
    
    
    
    public boolean editarPropiedad(String tipoPropiedad, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales, int piso, String letradep, boolean incluyeVentana, boolean incluyePatio, boolean incluyeMuebles, boolean incluyePiscina, boolean enConstruccion){
        
        
         Propiedad editar = buscarPropiedad(Direccion);
         
         if (editar != null){
            editar.setTipoPropiedad(tipoPropiedad);
              editar.setUbicacion(Ubicacion);
             editar.setPrecio(precio);
             editar.setDescripcion(Descripcion);
             editar.setMetrosCuadrados(MetrosCuadrados);
             editar.setAmbiente(Ambiente);
             editar.setCantBaños(CantBaños);
             editar.setAntiguedad(Antiguedad);
             editar.setExpensasMensuales(ExpensasMensuales);
             editar.setIncluyeVentana(incluyeVentana);
             editar.setPiso(piso);
             editar.setLetraDep(letradep);
                 editar.setIncluyeVentana(incluyeVentana);
                 editar.setIncluyePatio(incluyePatio);
                 editar.setIncluyeMuebles(incluyeMuebles);
                 editar.setIncluyePiscina(incluyePiscina);
                 editar.setEnConstruccion(enConstruccion);
                         
                 return true;         
             }
             
   
     return false;    
    }
    
    
    
    
    
    
    
    
    
    
}
