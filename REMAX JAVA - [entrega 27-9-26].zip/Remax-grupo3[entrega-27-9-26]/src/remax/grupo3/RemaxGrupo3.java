
package remax.grupo3;

import javax.swing.JOptionPane;

public class RemaxGrupo3 {
    
    public static void main(String[] args) {
        
    VentanaIngreso ventana = new VentanaIngreso();
   
    ventana.setLocationRelativeTo(null);
    ventana.setVisible(true);
                
               
    }
    
}
