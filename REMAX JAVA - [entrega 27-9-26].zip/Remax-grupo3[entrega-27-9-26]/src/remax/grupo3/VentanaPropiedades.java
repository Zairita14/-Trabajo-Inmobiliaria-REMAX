
package remax.grupo3;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class VentanaPropiedades extends javax.swing.JFrame {
private GestionPropiedad gestion;
    /**
     * Creates new form VentanaPropiedades
     */
    public VentanaPropiedades() {
        initComponents();
        gestion = new GestionPropiedad();
    }

    public void MostrarEnTabla(Propiedad p){
        DefaultTableModel modelo = (DefaultTableModel)tablaPropiedades.getModel();
        modelo.setRowCount(0);
        
        
            Object[] fila = {
                p.getTipoPropiedad(),
                p.getUbicacion(),
                p.getDireccion(),
                p.getPrecio(),
                p.getMetrosCuadrados(),
                p.getAmbiente(),
                p.getCantBaños(),
                p.getAntiguedad(),
                p.getReseña(),
                p.getExpensasMensuales(),
                p.getDescripcion(),
                p.getPiso(),
                p.getLetraDep(),
                p.isIncluyeVentana(),
                p.isIncluyePatio(),
                p.isIncluyeMuebles(),
                p.isIncluyePiscina(),
                p.isEnConstruccion()
            };
            
            modelo.addRow(fila);
        }
     
    public void actualizarTabla(){
        DefaultTableModel modelo = (DefaultTableModel)tablaPropiedades.getModel();
        modelo.setRowCount(0);
        
        for(Propiedad p : gestion.getLista_propiedades()){
            Object[] fila = {
               p.getTipoPropiedad(),
                p.getUbicacion(),
                p.getDireccion(),
                p.getPrecio(),
                p.getMetrosCuadrados(),
                p.getAmbiente(),
                p.getCantBaños(),
                p.getAntiguedad(),
                p.getReseña(),
                p.getExpensasMensuales(),
                p.getDescripcion(),
                p.getPiso(),
                p.getLetraDep(),
                p.isIncluyeVentana(),
                p.isIncluyePatio(),
                p.isIncluyeMuebles(),
                p.isIncluyePiscina(),
                p.isEnConstruccion()
            };
            
            modelo.addRow(fila);
        }
            
        
    }
    
    
           
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVolverMenu = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        boxTipoPropiedad = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaPropiedades = new javax.swing.JTable();
        txtUbicacion = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtMetrosCuadrados = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtAmbientes = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtCantidadBaños = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtAntiguedad = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtReseña = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtExpensas = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtDescripcion = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtPiso = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtLetraDep = new javax.swing.JTextField();
        chkIncluyeVentana = new javax.swing.JCheckBox();
        chkIncluyePatio = new javax.swing.JCheckBox();
        chkIncluyeMuebles = new javax.swing.JCheckBox();
        chkIncluyePiscina = new javax.swing.JCheckBox();
        chkEnConstruccion = new javax.swing.JCheckBox();
        btnAgregar = new javax.swing.JButton();
        Mostrar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnVolverMenu.setText("Volver al Menu");
        btnVolverMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverMenuActionPerformed(evt);
            }
        });

        jLabel1.setText("Ubicacion:");

        boxTipoPropiedad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Departamento", "Oficina", "PH", "Casa", "Quinta", "Terreno" }));
        boxTipoPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxTipoPropiedadActionPerformed(evt);
            }
        });

        tablaPropiedades.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Tipo", "Ubicacion", "Direccion", "Precio", "Descripcion", "Metros Cuadrados", "Ambientes", "Baños", "Antiguedad", "Reseña", "Expensas", "Piso", "Letra", "Ventana", "Patio", "Muebles", "Piscina", "En construccion"
            }
        ));
        jScrollPane1.setViewportView(tablaPropiedades);

        txtUbicacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUbicacionActionPerformed(evt);
            }
        });

        jLabel2.setText("Direccion:");

        txtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionActionPerformed(evt);
            }
        });

        txtPrecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPrecioActionPerformed(evt);
            }
        });

        jLabel3.setText("Precio:");

        txtMetrosCuadrados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMetrosCuadradosActionPerformed(evt);
            }
        });

        jLabel4.setText("M^2");

        txtAmbientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAmbientesActionPerformed(evt);
            }
        });

        jLabel5.setText("Ambientes");

        txtCantidadBaños.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadBañosActionPerformed(evt);
            }
        });

        jLabel6.setText("Cantidad de Baños");

        txtAntiguedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAntiguedadActionPerformed(evt);
            }
        });

        jLabel7.setText("Antiguedad");

        txtReseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtReseñaActionPerformed(evt);
            }
        });

        jLabel8.setText("Reseña (1-10)");

        txtExpensas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtExpensasActionPerformed(evt);
            }
        });

        jLabel9.setText("Expensas Mensuales:");

        jLabel10.setText("Descripción:");

        txtDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDescripcionActionPerformed(evt);
            }
        });

        jLabel11.setText("Tipo de Propiedad:");

        jLabel12.setText("Piso:");

        txtPiso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPisoActionPerformed(evt);
            }
        });

        jLabel13.setText("Letra del Departamento:");

        txtLetraDep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLetraDepActionPerformed(evt);
            }
        });

        chkIncluyeVentana.setText("Incluye ventana");
        chkIncluyeVentana.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkIncluyeVentanaActionPerformed(evt);
            }
        });

        chkIncluyePatio.setText("Incluye patio");
        chkIncluyePatio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkIncluyePatioActionPerformed(evt);
            }
        });

        chkIncluyeMuebles.setText("Incluye muebles");
        chkIncluyeMuebles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkIncluyeMueblesActionPerformed(evt);
            }
        });

        chkIncluyePiscina.setText("Incluye piscina");
        chkIncluyePiscina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkIncluyePiscinaActionPerformed(evt);
            }
        });

        chkEnConstruccion.setText("En construccion");
        chkEnConstruccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEnConstruccionActionPerformed(evt);
            }
        });

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        Mostrar.setText("Mostrar");
        Mostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MostrarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        jLabel14.setText("Direccion:");

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtMetrosCuadrados, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel5)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtAmbientes, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addComponent(jLabel8)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtReseña, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel9)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtExpensas))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel10)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel11)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(boxTipoPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtPiso, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel13)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtLetraDep, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(chkIncluyeVentana, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(chkIncluyePiscina))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(chkEnConstruccion)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(chkIncluyePatio)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(chkIncluyeMuebles))))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtCantidadBaños, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jLabel7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtAntiguedad, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtUbicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAgregar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Mostrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpiar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEditar))
                    .addComponent(btnVolverMenu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEliminar)
                        .addContainerGap(373, Short.MAX_VALUE))
                    .addComponent(jScrollPane1)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxTipoPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtUbicacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(txtMetrosCuadrados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(txtAmbientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtCantidadBaños, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(txtAntiguedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtExpensas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)
                            .addComponent(txtReseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtPiso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13)
                            .addComponent(txtLetraDep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chkIncluyeVentana)
                            .addComponent(chkIncluyePatio)
                            .addComponent(chkIncluyeMuebles))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(chkIncluyePiscina)
                            .addComponent(chkEnConstruccion))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnAgregar)
                            .addComponent(Mostrar)
                            .addComponent(btnLimpiar)
                            .addComponent(btnEditar))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 461, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnVolverMenu)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscar)
                            .addComponent(btnEliminar)
                            .addComponent(jLabel14))
                        .addGap(14, 14, 14))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVolverMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverMenuActionPerformed

        VentanaAgente vagente = new VentanaAgente();

        vagente.setLocationRelativeTo(null);
        vagente.setVisible(true);

        this.setVisible(false);
    }//GEN-LAST:event_btnVolverMenuActionPerformed

    private void boxTipoPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxTipoPropiedadActionPerformed

    }//GEN-LAST:event_boxTipoPropiedadActionPerformed

    private void txtUbicacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUbicacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUbicacionActionPerformed

    private void txtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionActionPerformed

    private void txtPrecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPrecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPrecioActionPerformed

    private void txtMetrosCuadradosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMetrosCuadradosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMetrosCuadradosActionPerformed

    private void txtAmbientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAmbientesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAmbientesActionPerformed

    private void txtCantidadBañosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadBañosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadBañosActionPerformed

    private void txtAntiguedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAntiguedadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAntiguedadActionPerformed

    private void txtReseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtReseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtReseñaActionPerformed

    private void txtExpensasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtExpensasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtExpensasActionPerformed

    private void txtDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDescripcionActionPerformed

    private void txtPisoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPisoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPisoActionPerformed

    private void txtLetraDepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLetraDepActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLetraDepActionPerformed

    private void chkIncluyeVentanaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkIncluyeVentanaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkIncluyeVentanaActionPerformed

    private void chkIncluyePatioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkIncluyePatioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkIncluyePatioActionPerformed

    private void chkIncluyeMueblesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkIncluyeMueblesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkIncluyeMueblesActionPerformed

    private void chkIncluyePiscinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkIncluyePiscinaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkIncluyePiscinaActionPerformed

    private void chkEnConstruccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkEnConstruccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkEnConstruccionActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
       
        
        String tipoPropiedad = (String) boxTipoPropiedad.getSelectedItem();
        String ubicacion = txtUbicacion.getText();
        String direccion = txtDireccion.getText();
        int precio = Integer.parseInt(txtPrecio.getText());
             double m2 = Double.parseDouble(txtMetrosCuadrados.getText());  
        int ambientes = Integer.parseInt(txtAmbientes.getText());
        int baños = Integer.parseInt(txtCantidadBaños.getText());
        
        int antiguedad = Integer.parseInt(txtAntiguedad.getText());
        int reseña = Integer.parseInt(txtReseña.getText());
        int expensas = Integer.parseInt(txtExpensas.getText());
        String descripcion = txtDescripcion.getText();
        int piso = Integer.parseInt(txtPiso.getText());
                String letra = txtLetraDep.getText();
                boolean incluyeVentana = chkIncluyeVentana.isSelected();
        boolean incluyePatio = chkIncluyePatio.isSelected();
        boolean incluyeMuebles = chkIncluyeMuebles.isSelected();
        boolean incluyePiscina = chkIncluyePiscina.isSelected();
        boolean enConstruccion = chkEnConstruccion.isSelected();
                
        
        
        if((reseña <1) || (reseña > 10)){
            JOptionPane.showMessageDialog(null, "ERROR - Reseña invalida");
            return;
        }
/*/
        if((telt.length() < 8) && (telt.length() <= 10)) {
            JOptionPane.showMessageDialog(null, "ERROR - El Telefono debe tener entre 8 y 10 digitos");
            return;
        }

        if(!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El campo nombre solo puede contener letras");
            return;
        }

        if(!apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
            JOptionPane.showMessageDialog(null, "ERROR - El campo apellido, solo puede contener letras");
            return;
        }

      
        
        
        if(!correo.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")){
            JOptionPane.showMessageDialog(null, "ERROR - Ingrese un correo electronico valido");
            return;
        }
        /*/
        Propiedad p = new Propiedad(tipoPropiedad,ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas,piso,letra,incluyeVentana,incluyePatio,incluyeMuebles,incluyePiscina,enConstruccion);

        gestion.agregarPropiedad(p);

        JOptionPane.showMessageDialog(null, "Propiedad registrada exitosamente");
        boxTipoPropiedad.setSelectedItem("Departamento");
        txtUbicacion.setText("");
        txtDireccion.setText("");
        txtPrecio.setText("");
         txtMetrosCuadrados.setText("");
        txtAmbientes.setText("");
        txtCantidadBaños.setText("");
        
       txtAntiguedad.setText("");
        txtReseña.setText("");
        txtExpensas.setText("");
        txtDescripcion.setText("");
        txtPiso.setText("");
       txtLetraDep.setText("");
       chkIncluyeVentana.setSelected(false);
        chkIncluyePatio.setSelected(false);
        chkIncluyeMuebles.setSelected(false);
        chkIncluyePiscina.setSelected(false);
        chkEnConstruccion.setSelected(false);
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void MostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MostrarActionPerformed
       
        
        actualizarTabla();
    }//GEN-LAST:event_MostrarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
       boxTipoPropiedad.setSelectedItem("Departamento");
        txtUbicacion.setText("");
        txtDireccion.setText("");
        txtPrecio.setText("");
         txtMetrosCuadrados.setText("");
        txtAmbientes.setText("");
        txtCantidadBaños.setText("");
        
       txtAntiguedad.setText("");
        txtReseña.setText("");
        txtExpensas.setText("");
        txtDescripcion.setText("");
        txtPiso.setText("");
       txtLetraDep.setText("");
       chkIncluyeVentana.setSelected(false);
        chkIncluyePatio.setSelected(false);
        chkIncluyeMuebles.setSelected(false);
        chkIncluyePiscina.setSelected(false);
        chkEnConstruccion.setSelected(false);
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        JOptionPane.showConfirmDialog(null,"Has seleccionado editar el registro");
 String tipoPropiedad = (String) boxTipoPropiedad.getSelectedItem();
        String ubicacion = txtUbicacion.getText();
        String direccion = txtDireccion.getText();
        int precio = Integer.parseInt(txtPrecio.getText());
             double m2 = Double.parseDouble(txtMetrosCuadrados.getText());  
        int ambientes = Integer.parseInt(txtAmbientes.getText());
        int baños = Integer.parseInt(txtCantidadBaños.getText());
        
        int antiguedad = Integer.parseInt(txtAntiguedad.getText());
        int reseña = Integer.parseInt(txtReseña.getText());
        int expensas = Integer.parseInt(txtExpensas.getText());
        String descripcion = txtDescripcion.getText();
        int piso = Integer.parseInt(txtPiso.getText());
                String letra = txtLetraDep.getText();
                boolean incluyeVentana = chkIncluyeVentana.isSelected();
        boolean incluyePatio = chkIncluyePatio.isSelected();
        boolean incluyeMuebles = chkIncluyeMuebles.isSelected();
        boolean incluyePiscina = chkIncluyePiscina.isSelected();
        boolean enConstruccion = chkEnConstruccion.isSelected();
                
        if((reseña <1) || (reseña > 10)){
            JOptionPane.showMessageDialog(null, "ERROR - Reseña invalida");
            return;
        }
        
        boolean datosEditados = gestion.editarPropiedad(tipoPropiedad,ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas,piso,letra,incluyeVentana,incluyePatio,incluyeMuebles,incluyePiscina,enConstruccion);

        if (datosEditados){
            JOptionPane.showMessageDialog(null, "Datos editados correctamente!");
            actualizarTabla();
        } else {
            JOptionPane.showMessageDialog(null, "ERROR: No se encontraron registros con esos datos");
        }

    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed

        Propiedad buscado = gestion.buscarPropiedad(txtBuscar.getText());

        if (buscado != null){
            MostrarEnTabla(buscado);
        }

    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        String buscar =txtBuscar.getText();

        boolean eliminar = gestion.eliminarPropiedad(buscar);

        if (eliminar){
            JOptionPane.showMessageDialog(null,"Propiedad eliminada exitosamente!");
            actualizarTabla();

        } else {
            JOptionPane.showMessageDialog(null,"No se encontro una propiedad con esa Direccion");

        }

    }//GEN-LAST:event_btnEliminarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedades.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPropiedades().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Mostrar;
    private javax.swing.JComboBox<String> boxTipoPropiedad;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnVolverMenu;
    private javax.swing.JCheckBox chkEnConstruccion;
    private javax.swing.JCheckBox chkIncluyeMuebles;
    private javax.swing.JCheckBox chkIncluyePatio;
    private javax.swing.JCheckBox chkIncluyePiscina;
    private javax.swing.JCheckBox chkIncluyeVentana;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaPropiedades;
    private javax.swing.JTextField txtAmbientes;
    private javax.swing.JTextField txtAntiguedad;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCantidadBaños;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtExpensas;
    private javax.swing.JTextField txtLetraDep;
    private javax.swing.JTextField txtMetrosCuadrados;
    private javax.swing.JTextField txtPiso;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtReseña;
    private javax.swing.JTextField txtUbicacion;
    // End of variables declaration//GEN-END:variables
}
