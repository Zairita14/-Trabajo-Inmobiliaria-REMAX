
package remax.grupo3;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class GestionOperacion {
      private ArrayList<Operacion> lista_operaciones;

    public GestionOperacion() {
       lista_operaciones = new ArrayList<>();
    }

    public ArrayList<Operacion> getLista_operaciones() {
        return lista_operaciones;
    }

    public void setLista_operaciones(ArrayList<Operacion> lista_operaciones) {
        this.lista_operaciones = lista_operaciones;
    }

    

    public void agregarOperacion(Operacion o){
       lista_operaciones.add(o);
    }
    
    public Operacion buscarOperacion(String direccion, int cliente, int agente, String fecha){
       
        for(Operacion o: lista_operaciones){
            if (o.getPropiedad().equals(direccion)) {

                if (o.getCliente() == cliente && o.getAgente() == agente && o.getFecha().equals(fecha)){
                return o;
                }    
            }
        }
       JOptionPane.showMessageDialog(null, "No se encontro ninguna operacion registrada con esa información");
       return null;
    
    }
    
        public boolean eliminarOperacion(String direccion, int cliente, int agente, String fecha){
            Operacion eliminar = buscarOperacion(direccion, cliente, agente, fecha);
            
            if (eliminar != null){
                
                lista_operaciones.remove(eliminar);
                return true;
                
                
            }
                  
            
            return false;
            
        }
    
    
    
    
    
    public boolean editarOperacion(String tipo, String direccion, int cliente, int agente, String fecha, int plazo){
        
        
         Operacion editar = buscarOperacion(direccion, cliente, agente, fecha);
         
         if (editar != null){
            editar.setTipo(tipo);
             editar.setPropiedad(direccion);
              editar.setCliente(cliente);
               editar.setAgente(agente);
                editar.setFecha(fecha);
                editar.setPlazoalquiler(plazo);
                 return true;         
             }
             
   
     return false;    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
