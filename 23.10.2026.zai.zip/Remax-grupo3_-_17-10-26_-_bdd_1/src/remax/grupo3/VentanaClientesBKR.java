package remax.grupo3;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class VentanaClientesBKR extends javax.swing.JFrame {

    public VentanaClientesBKR() {
        initComponents();
    }

   private void limpiar(){
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtEmail.setText("");
        txtContraseña.setText("");
        txtRecibo_sueldo.setText("");
        txtMascotas.setText("");
        txtHijos.setText("");
           
    }
    
    private void mostrarTabla(){
          ClienteDAO dao = new ClienteDAO();
        ArrayList<Cliente>lista_clientes=dao.listar();
        DefaultTableModel modelo=(DefaultTableModel)TablaClientes.getModel();
        
        modelo.setRowCount(0);
        for (Cliente c:lista_clientes) {
           modelo.addRow(new Object[]{
            c.getId(),
            c.getNombre(),
            c.getApellido(),
            c.getDni(),
            c.getTelefono(),
            c.getEmail(),
            c.getContraseña(),
            c.isRecibo_sueldo(),
            c.isMascotas(),
            c.isHijos(),
              
        });     
        }

    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TablaClientes = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtContraseña = new javax.swing.JTextField();
        btnMostrar = new javax.swing.JButton();
        txtRecibo_sueldo = new javax.swing.JTextField();
        txtMascotas = new javax.swing.JTextField();
        txtHijos = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellido", "DNI", "Telefono", "Email", "Contraseña", "¿Recibo sueldo?", "¿Mascotas?", "¿Hijos?"
            }
        ));
        TablaClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaClientes);

        jLabel1.setText("Nombre");

        jLabel2.setText("Apellido");

        jLabel3.setText("DNI");

        jLabel4.setText("Telefono");

        jLabel5.setText("Email");

        jLabel6.setText("Contraseña");

        jLabel7.setText("¿Recibo de sueldo?si/no");

        jLabel8.setText("¿Hijos?si/no");

        jLabel9.setText("¿Macotas?si/no");

        btnGuardar.setText("AGREGAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });

        txtDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDniActionPerformed(evt);
            }
        });

        btnMostrar.setText("MOSTRAR");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        txtRecibo_sueldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRecibo_sueldoActionPerformed(evt);
            }
        });

        txtMascotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMascotasActionPerformed(evt);
            }
        });

        txtHijos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHijosActionPerformed(evt);
            }
        });

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jLabel10.setText("DNI");

        jLabel11.setText("CLIENTES");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel8))
                                .addGap(20, 20, 20)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtHijos, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
                                    .addComponent(txtMascotas)
                                    .addComponent(txtRecibo_sueldo)
                                    .addComponent(txtContraseña)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel5))
                                .addGap(100, 100, 100)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNombre)
                                    .addComponent(txtDni)
                                    .addComponent(txtApellido)
                                    .addComponent(txtTelefono, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnGuardar)
                                .addGap(94, 94, 94)
                                .addComponent(btnMostrar)
                                .addGap(78, 78, 78)
                                .addComponent(btnEditar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnEliminar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(158, 158, 158)
                        .addComponent(jLabel10)
                        .addGap(18, 18, 18)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(btnVolver)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnVolver))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnBuscar)
                            .addComponent(jLabel10)
                            .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(134, 134, 134)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnMostrar)
                                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnEditar)
                                    .addComponent(btnEliminar)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(17, 17, 17)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel7)
                                    .addComponent(txtRecibo_sueldo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(24, 24, 24)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9)
                                    .addComponent(txtMascotas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(txtHijos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtHijosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHijosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHijosActionPerformed

    private void txtMascotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMascotasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMascotasActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
     String nombre =txtNombre.getText();
     String apellido=txtApellido.getText();
     String dni=txtDni.getText();
     String telefono=txtTelefono.getText();
     String email=txtEmail.getText();
     String contraseña=txtContraseña.getText();
     String recibo_sueldo=txtRecibo_sueldo.getText();
     String mascotas=txtMascotas.getText();
     String hijos=txtHijos.getText();
     
     if ((nombre.length() < 1) || (apellido.length() < 1) || (dni.length() < 1) ||  (telefono.length() < 1) || (email.length() < 1)||  (contraseña.length() < 1) || (recibo_sueldo.length() < 1)||  (mascotas.length() < 1) || (hijos.length() < 1)){
            JOptionPane.showMessageDialog(null, "ERROR: Hay campos vacios");
            return;
            
        }
     int dniNew = Integer.parseInt(dni);
     boolean recibo_sueldoNew = Boolean.parseBoolean(recibo_sueldo);
     boolean mascotasNew = Boolean.parseBoolean(mascotas);
     boolean hijosNew = Boolean.parseBoolean(hijos);
     
         if(!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
                JOptionPane.showMessageDialog(null, "ERROR: El campo nombre solo puede contener letras");
            return;
        
        }
         
         if(!apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
                JOptionPane.showMessageDialog(null, "ERROR: El campo apelido solo puede contener letras");
            return;
        
         }
          if(dni.length() != 8){
            JOptionPane.showMessageDialog(null, "ERROR: El DNI debe tener exactamente 8 digitos. Sin puntos");
            return;
        } 
         
         if(telefono.length()!=10){
             JOptionPane.showMessageDialog(null,"ERROR: SOLO PUEDE TENES EXACTAMENTE 10 DIGITOS. Sin espacios");
             return;
         }
        
             if(!email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")){
            JOptionPane.showMessageDialog(null, "ERROR: Ingrese un email valido!");
            return;
        }
           
     Cliente cliente_nuevo = new Cliente();
     ClienteDAO dao = new ClienteDAO();
     
      dao.insertar(cliente_nuevo);
      limpiar();
      mostrarTabla();
 
      
      JOptionPane.showMessageDialog(null,"Cliente guardado exitosamente");
          
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
  int fila = TablaClientes.getSelectedRow();

            if (fila == -1) {
                System.out.println("Debe seleccionar un cliente.");
                return;
            }
            int id = (int) TablaClientes.getValueAt(fila, 0);
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();
          
            int  dni = Integer.parseInt(txtDni.getText());
            String telefono = txtTelefono.getText();
            String email = txtEmail.getText();
            String contraseña = txtContraseña.getText();
            boolean recibo_sueldo = Boolean.parseBoolean(txtRecibo_sueldo.getText());
            boolean mascotas = Boolean.parseBoolean(txtMascotas.getText());
            boolean hijos = Boolean.parseBoolean(txtHijos.getText());

            Cliente clientee = new Cliente();
            clientee.setId(id);
            clientee.setNombre(nombre);
            clientee.setApellido(apellido);
            clientee.setDni(dni);
            clientee.setTelefono(telefono);
            clientee.setEmail(email);
            clientee.setContraseña(contraseña);
            clientee.setRecibo_sueldo(recibo_sueldo);
            clientee.setMascotas(mascotas);
            clientee.setHijos(hijos);

            ClienteDAO dao = new ClienteDAO();
            dao.actualizar(clientee);
            System.out.println("Datos modificados correctamente");     
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
       int fila= TablaClientes.getSelectedRow();
        if(fila == -1){
            System.out.println("Debes selecionar un Cliente ");
            return;
        }
          int respuesta = JOptionPane.showConfirmDialog( null, "¿Estás seguro de que querés eliminar este cliente?",  "",JOptionPane.YES_NO_OPTION);
           
        if (respuesta == JOptionPane.YES_OPTION) {   
        int id_cliente=(int)TablaClientes.getValueAt(fila,0);
        ClienteDAO dao= new ClienteDAO();
        dao.eliminar(id_cliente);
        
        JOptionPane.showMessageDialog(null,"Cliente eliminado exitosatosamente");
        mostrarTabla();
        limpiar();
        }else{
            JOptionPane.showMessageDialog(null,"No se ha eliminado ningun Cliente");
        }
        
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtRecibo_sueldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRecibo_sueldoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRecibo_sueldoActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
     VentanaOpcionesBroker ventanaOpciones = new VentanaOpcionesBroker();
     ventanaOpciones.setVisible(true);

    // Cerramos y destruimos la ventana actual de clientes para liberar memoria
    this.dispose();
    
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
   
        ClienteDAO dao = new ClienteDAO();
        ArrayList <Cliente> lista_clientes = dao.listar();
        DefaultTableModel modelo =(DefaultTableModel)TablaClientes.getModel();
        
        modelo.setRowCount(0);
        
        for(Cliente c: lista_clientes){
            modelo.addRow(new Object[]{
            c.getId(),
            c.getNombre(),
            c.getApellido(),
            c.getDni(),
            c.getTelefono(),
            c.getEmail(),
            c.getContraseña(),
            c.isRecibo_sueldo(),
            c.isMascotas(),
            c.isHijos()
            });
        }
        
         
        
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void TablaClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaClientesMouseClicked
    
        int fila = TablaClientes.getSelectedRow();
        
        int id = (int) TablaClientes.getValueAt(fila,0);
        
        String nombre = TablaClientes.getValueAt(fila,1).toString();
        String apellido = TablaClientes.getValueAt(fila,2).toString();
        String telefono = TablaClientes.getValueAt(fila,3).toString();
        String email = TablaClientes.getValueAt(fila,4).toString();
        String contraseña = TablaClientes.getValueAt(fila,5).toString();
        String recibo_sueldo = TablaClientes.getValueAt(fila,6).toString();
        String mascotas = TablaClientes.getValueAt(fila,7).toString();
        String hijos = TablaClientes.getValueAt(fila,8).toString();
        
        txtNombre.setText(nombre);
        txtApellido.setText(apellido);
        txtTelefono.setText(telefono);
        txtEmail.setText(email);
        txtContraseña.setText(contraseña);
        txtRecibo_sueldo.setText(recibo_sueldo);
        txtMascotas.setText(mascotas);
        txtHijos.setText(hijos);
        
        System.out.println("ID seleccionado: "+ id);
    }//GEN-LAST:event_TablaClientesMouseClicked

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
       int dni = Integer.parseInt(txtDni.getText());
        ClienteDAO dao = new ClienteDAO();
        ArrayList<Cliente> lista_clientes = dao.buscarPorDni(dni);
        DefaultTableModel modelo = (DefaultTableModel) TablaClientes.getModel();
        modelo.setRowCount(0);
        
        for (Cliente c : lista_clientes) {
        modelo.addRow(new Object[]{
            c.getId(),
            c.getNombre(),
            c.getApellido(),
            c.getDni(),
            c.getTelefono(),
            c.getEmail(),
            c.getContraseña(),
            c.isRecibo_sueldo(),
            c.isMascotas(),
            c.isHijos()
        });
        
        }    
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDniActionPerformed

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaClientes;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtContraseña;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtHijos;
    private javax.swing.JTextField txtMascotas;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtRecibo_sueldo;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables

}