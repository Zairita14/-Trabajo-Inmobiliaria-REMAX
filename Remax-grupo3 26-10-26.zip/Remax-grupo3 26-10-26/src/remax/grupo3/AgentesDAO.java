package remax.grupo3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AgentesDAO {

    public void insertar(Agentes a) {
        String consulta_sql = "INSERT INTO Agentes(nombre,apellido,dni,telefono,email,contraseña,puntuacion) VALUES (?,?,?,?,?,?,?)";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            sentencia_sql.setString(1, a.getNombre());
            sentencia_sql.setString(2, a.getApellido());
            sentencia_sql.setInt(3, a.getDni());
            sentencia_sql.setInt(4, a.getTelefono());
            sentencia_sql.setString(5, a.getEmail());
            sentencia_sql.setString(6, a.getContraseña());
            sentencia_sql.setInt(7, a.getPuntuacion());

            sentencia_sql.executeUpdate();

          

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
        }
         JOptionPane.showMessageDialog(null,"Persona guardada exitosamente");
    }

    public ArrayList<Agentes> listar() {
        ArrayList<Agentes> lista_agente = new ArrayList<>();

        String consulta_sql = "Select * From Agentes";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Agentes agente = new Agentes();
                agente.setId_agente(resultado.getInt("id_agente"));
                agente.setNombre(resultado.getString("nombre"));
                agente.setApellido(resultado.getString("apellido"));
                agente.setDni(resultado.getInt("dni"));
                agente.setTelefono(resultado.getInt("telefono"));
                agente.setEmail(resultado.getString("email"));
                agente.setContraseña(resultado.getString("contraseña"));
                agente.setPuntuacion(resultado.getInt("puntuacion"));

                lista_agente.add(agente);
                System.out.println("~~~~~~~~~~~~~");

            }
         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
        }
        return lista_agente;
    }

  public void actualizar(Agentes a) {

    String consulta_sql = "UPDATE Agentes SET nombre = ?, apellido = ?, dni = ?, telefono = ?, email = ?, contraseña = ?, puntuacion = ? WHERE id_agente = ?";

    try {
        Connection conexion = Conexion.conectar();
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

        sentencia_sql.setString(1, a.getNombre());
        sentencia_sql.setString(2, a.getApellido());
        sentencia_sql.setInt(3, a.getDni());
        sentencia_sql.setInt(4, a.getTelefono());
        sentencia_sql.setString(5, a.getEmail());
        sentencia_sql.setString(6, a.getContraseña());
        sentencia_sql.setInt(7, a.getPuntuacion());
        sentencia_sql.setInt(8, a.getId_agente());

        sentencia_sql.executeUpdate();


    } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        }
    JOptionPane.showMessageDialog(null,"Agente actualizado exitosamente");
}

    public void eliminar(int id) {
        String consulta_sql = "DELETE From Agentes Where id_agente = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
           

         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        }
         JOptionPane.showMessageDialog(null,"Agente eliminado correctamente ");
    }

    public ArrayList<Agentes> buscarPorDni(int dniBuscado) {
        ArrayList<Agentes> agentes = new ArrayList<>();
        String consulta_sql = "Select * From Agentes Where dni = ?";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, dniBuscado);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Agentes agente = new Agentes();
                agente.setId_agente(resultado.getInt("id_agente"));
                agente.setNombre(resultado.getString("nombre"));
                agente.setApellido(resultado.getString("apellido"));
                agente.setDni(resultado.getInt("dni"));
                agente.setTelefono(resultado.getInt("telefono"));
                agente.setEmail(resultado.getString("email"));
                agente.setContraseña(resultado.getString("contraseña"));
                agente.setPuntuacion(resultado.getInt("puntuacion"));

                agentes.add(agente);
                System.out.println("~~~~~~~~~~~~~");

            }
         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        }
        return agentes;
    }

}
