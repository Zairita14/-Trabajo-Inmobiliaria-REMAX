
package remax.grupo3;

public class Ambiente {
    private int id_ambiente;
    private String nombre;
    private boolean incluyeMuebles;
    private boolean incluyeVentana;
    private boolean incluyePatio;
    private boolean incluyePiscina;

    public Ambiente(String nombre, boolean incluyeMuebles, boolean incluyeVentana, boolean incluyePatio, boolean incluyePiscina) {
        this.id_ambiente = id_ambiente;
        this.nombre = nombre;
        this.incluyeMuebles = incluyeMuebles;
        this.incluyeVentana = incluyeVentana;
        this.incluyePatio = incluyePatio;
        this.incluyePiscina = incluyePiscina;
    }

    public int getId_ambiente() {
        return id_ambiente;
    }

    public void setId_ambiente(int id_ambiente) {
        this.id_ambiente = id_ambiente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isIncluyeMuebles() {
        return incluyeMuebles;
    }

    public void setIncluyeMuebles(boolean incluyeMuebles) {
        this.incluyeMuebles = incluyeMuebles;
    }

    public boolean isIncluyeVentana() {
        return incluyeVentana;
    }

    public void setIncluyeVentana(boolean incluyeVentana) {
        this.incluyeVentana = incluyeVentana;
    }

    public boolean isIncluyePatio() {
        return incluyePatio;
    }

    public void setIncluyePatio(boolean incluyePatio) {
        this.incluyePatio = incluyePatio;
    }

    public boolean isIncluyePiscina() {
        return incluyePiscina;
    }

    public void setIncluyePiscina(boolean incluyePiscina) {
        this.incluyePiscina = incluyePiscina;
    }

    


}
