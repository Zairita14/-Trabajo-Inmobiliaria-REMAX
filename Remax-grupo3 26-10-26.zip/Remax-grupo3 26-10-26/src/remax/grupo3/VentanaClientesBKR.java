package remax.grupo3;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class VentanaClientesBKR extends javax.swing.JFrame {

    public VentanaClientesBKR() {
        initComponents();
    }

   private void limpiar(){
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtTelefono.setText("");
        txtEmail.setText("");
        txtEmail.setText("");
        txtContraseña.setText("");
        chkRecibo_sueldoSi.setSelected(false);
        chkMascotasSi.setSelected(false);
        chkHijosSi.setSelected(false);
        chkRecibo_sueldoNo.setSelected(false);
        chkMascotasNo.setSelected(false);
        chkHijosNo.setSelected(false);
           
    }
    
    private void mostrarTabla(){
          ClienteDAO dao = new ClienteDAO();
        ArrayList<Cliente>lista_clientes=dao.listar();
        DefaultTableModel modelo=(DefaultTableModel)TablaClientes.getModel();
        
        modelo.setRowCount(0);
        for (Cliente c:lista_clientes) {
           modelo.addRow(new Object[]{
            c.getId(),
            c.getNombre(),
            c.getApellido(),
            c.getDni(),
            c.getTelefono(),
            c.getEmail(),
            c.getContraseña(),
            c.isRecibo_sueldo(),
            c.isMascotas(),
            c.isHijos(),
              
        });     
        }

    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaClientes = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        txtNombre = new javax.swing.JTextField();
        txtApellido = new javax.swing.JTextField();
        txtDni = new javax.swing.JTextField();
        txtTelefono = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtContraseña = new javax.swing.JTextField();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        chkRecibo_sueldoSi = new javax.swing.JCheckBox();
        chkMascotasSi = new javax.swing.JCheckBox();
        chkHijosSi = new javax.swing.JCheckBox();
        chkRecibo_sueldoNo = new javax.swing.JCheckBox();
        chkMascotasNo = new javax.swing.JCheckBox();
        chkHijosNo = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        TablaClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nombre", "Apellido", "DNI", "Telefono", "Email", "Contraseña", "¿Recibo sueldo?", "¿Mascotas?", "¿Hijos?"
            }
        ));
        TablaClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablaClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablaClientes);

        jLabel1.setText("Nombre");

        jLabel2.setText("Apellido");

        jLabel3.setText("DNI");

        jLabel4.setText("Telefono");

        jLabel5.setText("Email");

        jLabel6.setText("Contraseña");

        jLabel7.setText("¿Tenes recibo de sueldo?");

        jLabel8.setText("¿Tenes hijos?");

        jLabel9.setText("¿Tenes macotas?");

        btnGuardar.setText("AGREGAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });

        txtDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDniActionPerformed(evt);
            }
        });

        btnMostrar.setText("MOSTRAR");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnEditar.setText("EDITAR");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnVolver.setText("Volver");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jLabel10.setText("DNI");

        jLabel11.setText("Clientes");

        buttonGroup1.add(chkRecibo_sueldoSi);
        chkRecibo_sueldoSi.setText("Si");
        chkRecibo_sueldoSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkRecibo_sueldoSiActionPerformed(evt);
            }
        });

        buttonGroup2.add(chkMascotasSi);
        chkMascotasSi.setText("Si");
        chkMascotasSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkMascotasSiActionPerformed(evt);
            }
        });

        buttonGroup3.add(chkHijosSi);
        chkHijosSi.setText("Si");
        chkHijosSi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkHijosSiActionPerformed(evt);
            }
        });

        buttonGroup1.add(chkRecibo_sueldoNo);
        chkRecibo_sueldoNo.setText("No");

        buttonGroup2.add(chkMascotasNo);
        chkMascotasNo.setText("No");

        buttonGroup3.add(chkHijosNo);
        chkHijosNo.setText("No");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(830, 830, 830))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9)
                            .addComponent(btnVolver))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(chkRecibo_sueldoSi)
                                    .addComponent(chkMascotasSi)
                                    .addComponent(chkHijosSi))
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(chkMascotasNo)
                                            .addComponent(chkRecibo_sueldoNo))
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(chkHijosNo)
                                        .addGap(95, 95, 95))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(txtContraseña))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 277, Short.MAX_VALUE)
                            .addComponent(txtDni, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtApellido, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmail))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(btnGuardar)
                        .addGap(94, 94, 94)
                        .addComponent(btnMostrar)
                        .addGap(78, 78, 78)
                        .addComponent(btnEditar)
                        .addGap(75, 75, 75)
                        .addComponent(btnEliminar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(18, 18, 18)
                                .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBuscar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 604, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnBuscar)
                        .addComponent(jLabel10)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnMostrar)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnEditar)
                            .addComponent(btnEliminar)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(chkRecibo_sueldoSi)
                            .addComponent(chkRecibo_sueldoNo))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(chkMascotasSi)
                            .addComponent(chkMascotasNo))
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(chkHijosSi)
                            .addComponent(chkHijosNo))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnVolver)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
   
     String nombre = txtNombre.getText();
   String apellido = txtApellido.getText();
   String dni = txtDni.getText();
   String telefono = txtTelefono.getText();
   String email = txtEmail.getText();
   String contraseña = txtContraseña.getText();
   boolean recibo_sueldoNew = chkRecibo_sueldoSi.isSelected();
   boolean mascotasNew = chkMascotasSi.isSelected();
   boolean hijosNew = chkHijosSi.isSelected();
   
   if ((nombre.length() < 1) || (apellido.length() < 1) || (dni.length() < 1) ||  (telefono.length() < 1) || (email.length() < 1)||  (contraseña.length() < 1)){
        JOptionPane.showMessageDialog(null, "ERROR: Hay campos vacios");
        return;
    }
    
   if(!nombre.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
        JOptionPane.showMessageDialog(null, "ERROR: El campo nombre solo puede contener letras");
        return;
    }
     
   if(!apellido.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+")){
        JOptionPane.showMessageDialog(null, "ERROR: El campo apellido solo puede contener letras");
        return;
   }
   
   if(dni.length() != 8){
        JOptionPane.showMessageDialog(null, "ERROR: El DNI debe tener exactamente 8 digitos. Sin puntos");
        
          return; 
   }
      
     
   if(telefono.length() != 10){
       JOptionPane.showMessageDialog(null,"ERROR: EL TELEFONO DEBE TENER EXACTAMENTE 10 DIGITOS. Sin espacios");
       return;
   }
    
   if(!email.matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")){
        JOptionPane.showMessageDialog(null, "ERROR: Ingrese un email valido!");
        return;
   }


   int dniNew = Integer.parseInt(dni);
     
 
   Cliente cliente_nuevo = new Cliente();
   
   cliente_nuevo.setNombre(nombre);
   cliente_nuevo.setApellido(apellido);
   cliente_nuevo.setDni(dniNew);
   cliente_nuevo.setTelefono(telefono);
   cliente_nuevo.setEmail(email);
   cliente_nuevo.setContraseña(contraseña);
   cliente_nuevo.setRecibo_sueldo(recibo_sueldoNew);
   cliente_nuevo.setMascotas(mascotasNew);
   cliente_nuevo.setHijos(hijosNew);

   ClienteDAO dao = new ClienteDAO();
   dao.insertar(cliente_nuevo);
   
   limpiar();
   mostrarTabla();
  

          
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
  int fila = TablaClientes.getSelectedRow();

            if (fila == -1) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un cliente.");
                return;
            }
            int id = (int) TablaClientes.getValueAt(fila, 0);
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();         
            int  dni = Integer.parseInt(txtDni.getText());
            String telefono = txtTelefono.getText();
            String email = txtEmail.getText();
            String contraseña = txtContraseña.getText();
            

            Cliente clientee = new Cliente();
            clientee.setId(id);
            clientee.setNombre(nombre);
            clientee.setApellido(apellido);
            clientee.setDni(dni);
            clientee.setTelefono(telefono);
            clientee.setEmail(email);
            clientee.setContraseña(contraseña);
            clientee.setRecibo_sueldo(chkRecibo_sueldoSi.isSelected());
            clientee.setMascotas(chkMascotasSi.isSelected());
            clientee.setHijos(chkHijosSi.isSelected());

            ClienteDAO dao = new ClienteDAO();
            dao.actualizar(clientee);
            mostrarTabla();
              
            
           
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
       int fila= TablaClientes.getSelectedRow();
        if(fila == -1){
            JOptionPane.showMessageDialog(null, "Debe seleccionar un cliente.");
            return;
        }
          int respuesta = JOptionPane.showConfirmDialog( null, "¿Estás seguro de que querés eliminar este cliente?",  "",JOptionPane.YES_NO_OPTION);
           
        if (respuesta == JOptionPane.YES_OPTION) {   
        int id_cliente=(int)TablaClientes.getValueAt(fila,0);
        ClienteDAO dao= new ClienteDAO();
        dao.eliminar(id_cliente);
       
        mostrarTabla();
        limpiar();
        }else{
            JOptionPane.showMessageDialog(null,"No se ha eliminado ningun Cliente");
        }
        
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
     VentanaOpcionesBroker ventanaOpciones = new VentanaOpcionesBroker();
     ventanaOpciones.setVisible(true);

    // Cerramos y destruimos la ventana actual de clientes para liberar memoria
    this.dispose();
    
    }//GEN-LAST:event_btnVolverActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
            mostrarTabla();
        
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void TablaClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablaClientesMouseClicked
    
        int fila = TablaClientes.getSelectedRow();
        
        int id = (int) TablaClientes.getValueAt(fila,0);
        
        String nombre = TablaClientes.getValueAt(fila,1).toString();
        String apellido = TablaClientes.getValueAt(fila,2).toString();
        String dni = TablaClientes.getValueAt(fila,3).toString();
        String telefono = TablaClientes.getValueAt(fila,4).toString();
        String email = TablaClientes.getValueAt(fila,5).toString();
        String contraseña = TablaClientes.getValueAt(fila,6).toString();
        boolean recibo_sueldo = Boolean.parseBoolean(TablaClientes.getValueAt(fila, 7).toString());
        boolean mascotas = Boolean.parseBoolean(TablaClientes.getValueAt(fila, 8).toString());
        boolean hijos = Boolean.parseBoolean(TablaClientes.getValueAt(fila, 9).toString());
        
        
        
        /*/
        boolean mascotas = (boolean) TablaClientes.getValueAt(fila, 8);
        boolean hijos = (boolean) TablaClientes.getValueAt(fila, 9);
/*/
        txtNombre.setText(nombre);
        txtApellido.setText(apellido);
        txtDni.setText(dni);
        txtTelefono.setText(telefono);
        txtEmail.setText(email);
        txtContraseña.setText(contraseña);
        chkRecibo_sueldoSi.setSelected(recibo_sueldo);
        chkRecibo_sueldoNo.setSelected(!recibo_sueldo);
        chkMascotasSi.setSelected(mascotas);
        chkMascotasNo.setSelected(!mascotas);
        chkHijosSi.setSelected(hijos);
        chkHijosNo.setSelected(!hijos);
        
        
        System.out.println("ID seleccionado: "+ id);
    

    }//GEN-LAST:event_TablaClientesMouseClicked

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
     
 
    if (txtBuscar.getText().isEmpty()) {
        JOptionPane.showMessageDialog(null, "Por favor ingrese un DNI");
        return;
    }
    
    int dni = Integer.parseInt(txtBuscar.getText());
    ClienteDAO dao = new ClienteDAO();
    ArrayList<Cliente> lista_clientes = dao.buscarPorDni(dni);
    DefaultTableModel modelo = (DefaultTableModel) TablaClientes.getModel();
    modelo.setRowCount(0);
    
    for (Cliente c : lista_clientes) {
        modelo.addRow(new Object[]{
            c.getId(),
            c.getNombre(),
            c.getApellido(),
            c.getDni(),
            c.getTelefono(),
            c.getEmail(),
            c.getContraseña(),
            c.isRecibo_sueldo(),
            c.isMascotas(),
            c.isHijos()
        });
     }
         
    }//GEN-LAST:event_btnBuscarActionPerformed

    
    private void txtDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDniActionPerformed

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void chkRecibo_sueldoSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkRecibo_sueldoSiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkRecibo_sueldoSiActionPerformed

    private void chkMascotasSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkMascotasSiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkMascotasSiActionPerformed

    private void chkHijosSiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkHijosSiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkHijosSiActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
   mostrarTabla();
    }//GEN-LAST:event_formComponentShown

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablaClientes;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnVolver;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JCheckBox chkHijosNo;
    private javax.swing.JCheckBox chkHijosSi;
    private javax.swing.JCheckBox chkMascotasNo;
    private javax.swing.JCheckBox chkMascotasSi;
    private javax.swing.JCheckBox chkRecibo_sueldoNo;
    private javax.swing.JCheckBox chkRecibo_sueldoSi;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtContraseña;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefono;
    // End of variables declaration//GEN-END:variables

}