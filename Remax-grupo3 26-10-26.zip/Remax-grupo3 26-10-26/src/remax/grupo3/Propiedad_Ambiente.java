
package remax.grupo3;

public class Propiedad_Ambiente {
    private int id_propiedad_ambiente;
    private int id_ambiente;
    private int id_propiedad;

    public Propiedad_Ambiente(int id_ambiente, int id_propiedad) {
        this.id_ambiente = id_ambiente;
        this.id_propiedad = id_propiedad;
    }

    public int getId_propiedad_ambiente() {
        return id_propiedad_ambiente;
    }

    public void setId_propiedad_ambiente(int id_propiedad_ambiente) {
        this.id_propiedad_ambiente = id_propiedad_ambiente;
    }

    public int getId_ambiente() {
        return id_ambiente;
    }

    public void setId_ambiente(int id_ambiente) {
        this.id_ambiente = id_ambiente;
    }

    public int getId_propiedad() {
        return id_propiedad;
    }

    public void setId_propiedad(int id_propiedad) {
        this.id_propiedad = id_propiedad;
    }
    
    
    
    
}
