
package remax.grupo3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class OperacionDAO {
    
    public void insertar (Operacion o){
        String consulta_sql = "INSERT INTO operaciones values (default, ?,?,?,?,?,?,?,?)";
        
        
        
        
        
        try {
        
        Connection conexion = Conexion.conectar();
        
        PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
        
        
        sentencia_sql.setInt(1, o.getId_propiedad());
         sentencia_sql.setInt(2, o.getId_agente());
          sentencia_sql.setInt(3, o.getId_cliente());
       sentencia_sql.setString(4, o.getFecha_operacion());
       sentencia_sql.setString(5, o.getTipoOperacion());
       sentencia_sql.setString(6, o.getFecha_inicio());
       sentencia_sql.setInt(7, o.getPlazo_meses());
        sentencia_sql.setString(8, o.getFecha_compra());
        
        sentencia_sql.executeUpdate();
        
            
        // HACER UNB TRIGGER PARA REVISAR QUE SI EXISTA CADA ID EN LAS TABLAS RESPECTIVAS !!!!! skldajaasldsl
        } catch (SQLException ex){
             JOptionPane.showMessageDialog(null,"ERROR:" + ex.getMessage());
            return;
        }
        
        JOptionPane.showMessageDialog(null,"Operacion guardada exitosamente");
        
    }

    
    public ArrayList<Operacion> listar(){
        ArrayList <Operacion> lista = new ArrayList<>();
        String consulta_sql = "select * from operaciones";
        
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                Operacion o= new Operacion(1,1,1,"","","",1,"");
                
                
                o.setId_operacion(resultado.getInt("id_operacion"));
                o.setId_propiedad(resultado.getInt("id_propiedad"));
                o.setId_agente(resultado.getInt("id_agente"));
                o.setId_cliente(resultado.getInt("id_cliente"));
                o.setFecha_operacion(resultado.getString("fecha_operacion"));
                o.setTipoOperacion(resultado.getString("tipoOperacion"));
                o.setFecha_inicio(resultado.getString("fecha_inicio"));
                o.setPlazo_meses(resultado.getInt("plazo_meses"));
                o.setFecha_compra(resultado.getString("fecha_compra"));
          
                
                lista.add(o);
                System.out.println("---------------");
            } 
                
            } catch (SQLException ex){
                    
                    System.out.println("ERROR: " + ex.getMessage());
                    }
            return lista;
            
            
            
         
        }
        
   
    public ArrayList<Operacion> listarCompras(){
        ArrayList <Operacion> lista = new ArrayList<>();
        String consulta_sql = "select * from operaciones where tipoOperacion = 'Compra'";
        
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                Operacion o= new Operacion(1,1,1,"","","",1,"");
                
                
                o.setId_operacion(resultado.getInt("id_operacion"));
                o.setId_propiedad(resultado.getInt("id_propiedad"));
                o.setId_agente(resultado.getInt("id_agente"));
                o.setId_cliente(resultado.getInt("id_cliente"));
                o.setFecha_operacion(resultado.getString("fecha_operacion"));
                o.setTipoOperacion(resultado.getString("tipoOperacion"));
                o.setFecha_inicio(resultado.getString("fecha_inicio"));
                o.setPlazo_meses(resultado.getInt("plazo_meses"));
                o.setFecha_compra(resultado.getString("fecha_compra"));
          
                
                lista.add(o);
                System.out.println("---------------");
            } 
                
            } catch (SQLException ex){
                    
                    System.out.println("ERROR: " + ex.getMessage());
                    }
            return lista;
            
            
            
         
        }
    
    
    public ArrayList<Operacion> listarAlquileres(){
        ArrayList <Operacion> lista = new ArrayList<>();
        String consulta_sql = "select * from operaciones where tipoOperacion = 'Alquiler'";
        
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            ResultSet resultado = sentencia_sql.executeQuery();
            
            while (resultado.next()){
                Operacion o= new Operacion(1,1,1,"","","",1,"");
                
                
                o.setId_operacion(resultado.getInt("id_operacion"));
                o.setId_propiedad(resultado.getInt("id_propiedad"));
                o.setId_agente(resultado.getInt("id_agente"));
                o.setId_cliente(resultado.getInt("id_cliente"));
                o.setFecha_operacion(resultado.getString("fecha_operacion"));
                o.setTipoOperacion(resultado.getString("tipoOperacion"));
                o.setFecha_inicio(resultado.getString("fecha_inicio"));
                o.setPlazo_meses(resultado.getInt("plazo_meses"));
                o.setFecha_compra(resultado.getString("fecha_compra"));
          
                
                lista.add(o);
                System.out.println("---------------");
            } 
                
            } catch (SQLException ex){
                    
                    System.out.println("ERROR: " + ex.getMessage());
                    }
            return lista;
            
            
            
         
        }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        public void actualizar(Operacion o){
            String consulta_sql = "Update operaciones set id_propiedad = ?, id_cliente = ?, tipoOperacion = ?, fecha_operacion = ?, fecha_inicio =?, plazo_meses = ? ,fecha_compra = ? where id_operacion = ?";
            
            try {
                Connection conexion = Conexion.conectar();
                
                PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
                
               
                sentencia_sql.setInt(1, o.getId_propiedad());
                 sentencia_sql.setInt(2, o.getId_cliente());
                sentencia_sql.setString(3, o.getTipoOperacion());
                sentencia_sql.setString(4, o.getFecha_operacion());
                  sentencia_sql.setString(5, o.getFecha_inicio());
                  sentencia_sql.setInt(6, o.getPlazo_meses());
                sentencia_sql.setString(7, o.getFecha_compra());
                 sentencia_sql.setInt(8, o.getId_operacion());
                
                sentencia_sql.executeUpdate();
                
                

            } catch (SQLException ex){
                JOptionPane.showMessageDialog(null, "ERROR: " + ex.getMessage());
                return;
            }
            JOptionPane.showMessageDialog(null, "Datos actualizados exitosamente");
            
        }
        
       
        public void eliminar(int id){
           String consulta_sql = "DELETE from operaciones where id_operacion = ?";
           
           try {
               
               Connection conexion = Conexion.conectar();
               
               PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
               sentencia_sql.setInt(1,id);
               sentencia_sql.executeUpdate();
                              
               
           } catch (SQLException ex){
               System.out.println("ERROR:" + ex.getMessage());
               return;
           }
            JOptionPane.showMessageDialog(null, "Operación eliminada correctamente!");
                   
            
            
            
            
        }
        
 
    
    
    
    
    
    
    
    
    
    
    
}
