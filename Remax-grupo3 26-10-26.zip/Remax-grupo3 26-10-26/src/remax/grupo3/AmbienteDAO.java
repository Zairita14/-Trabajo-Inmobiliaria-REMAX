package remax.grupo3;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AmbienteDAO {
    
   
public void insertarAPropiedad(int id_propiedad, int id_ambiente){
    String consulta_sql = "INSERT INTO Propiedad_Ambientes  values (default, ?,?)";
    
    try{
    Connection conexion= Conexion.conectar();
     PreparedStatement sentencia_sql= conexion.prepareStatement(consulta_sql);
     
     sentencia_sql.setInt(1, id_ambiente);
        sentencia_sql.setInt(2, id_propiedad);
 
    sentencia_sql.executeUpdate();
           
} catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Ambiente agregado exitosamente en la propiedad");
}



public void borrarDePropiedad(int id_propiedad, int id_ambiente){
    String consulta_sql = "Delete from Propiedad_Ambientes where id_propiedad = ? and id_ambiente = ? limit 1 ";
    
    try{
    Connection conexion= Conexion.conectar();
     PreparedStatement sentencia_sql= conexion.prepareStatement(consulta_sql);
     
     sentencia_sql.setInt(2, id_ambiente);
        sentencia_sql.setInt(1, id_propiedad);
 
    sentencia_sql.executeUpdate();
           
} catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Ambiente borrado exitosamente de la propiedad");
}



















public ArrayList<Ambiente> listarPorIdPropiedad(int id_propiedad) {
       ArrayList<Ambiente>lista_ambientes = new ArrayList<>();
       String consulta_sql ="select Ambientes.* from Ambientes inner join Propiedad_Ambientes on Propiedad_Ambientes.id_ambiente = Ambientes.id_ambiente where Propiedad_Ambientes.id_propiedad = ?";
       try{
           Connection conexion = Conexion.conectar();
           PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
           sentencia_sql.setInt(1,id_propiedad);
           ResultSet resultado= sentencia_sql.executeQuery();
           while (resultado.next()){
               Ambiente ambiente = new Ambiente("s",true,true,true,true);
               ambiente.setId_ambiente(resultado.getInt("id_ambiente"));
               ambiente.setNombre(resultado.getString("nombre"));
               ambiente.setIncluyeMuebles(resultado.getBoolean("incluyeMuebles"));
               ambiente.setIncluyeVentana(resultado.getBoolean("incluyeVentana"));
               ambiente.setIncluyePatio(resultado.getBoolean("incluyePatio"));
               ambiente.setIncluyePiscina(resultado.getBoolean("incluyePiscina"));
               lista_ambientes.add(ambiente);
               
           }
           
       }catch (SQLException ex){
           System.out.println("ERROR: " + ex.getMessage());
       }
       return lista_ambientes;
    }


public ArrayList<Ambiente> listar() {
 ArrayList<Ambiente>lista_ambientes = new ArrayList<>();
       String consulta_sql ="SELECT * FROM Ambientes";
       try{
           Connection conexion = Conexion.conectar();
           PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
           //sentencia_sql.setInt(1,dni_buscado);
           ResultSet resultado= sentencia_sql.executeQuery();
           while (resultado.next()){
               Ambiente ambiente = new Ambiente("s",true,true,true,true);
               ambiente.setId_ambiente(resultado.getInt("id_ambiente"));
               ambiente.setNombre(resultado.getString("Nombre"));
               ambiente.setIncluyeMuebles(resultado.getBoolean("incluyeMuebles"));
               ambiente.setIncluyeVentana(resultado.getBoolean("incluyeVentana"));
               ambiente.setIncluyePatio(resultado.getBoolean("incluyePatio"));
               ambiente.setIncluyePiscina(resultado.getBoolean("incluyePiscina"));
               lista_ambientes.add(ambiente);
               
           }
           
       }catch (SQLException ex){
           System.out.println("ERROR: " + ex.getMessage());
       }
       return lista_ambientes;
    }


















public void eliminarMuchosAMuchos(int id_ambiente, int id_propiedad){
    //convertir en procedimiento despues
        String consulta_sql = "DELETE FROM Ambientes WHERE id_ambiente = ? and id_propiedad = ? limit 1";
       
        try {
            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id_ambiente);
            sentencia_sql.setInt(2, id_propiedad);
            sentencia_sql.executeUpdate();
           
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Ambiente eliminado exitosamente de la propiedad");
    }


public void agregarMuchosAMuchos(int id_ambiente, int id_propiedad){
    //convertir en procedimiento despues
        String consulta_sql = "insert into Propiedad_Ambientes values(default, ?, ?)";
       
        try {
            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id_ambiente);
            sentencia_sql.setInt(2, id_propiedad);
            sentencia_sql.executeUpdate();
           
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Ambiente agregado exitosamente a la propiedad");
    }




















/*/



public void eliminar(int id_ambiente){
        String consulta_sql = "DELETE FROM Ambientes WHERE id_ambiente = ?";
       
        try {
            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id_ambiente);
            sentencia_sql.executeUpdate();
           
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Ambiente eliminado exitosamente");
    }

public void actualizar(Ambiente ambiente){
        String consulta_sql = "UPDATE Ambientes SET nombre = ?, incluyeMuebles = ? incluyeVentana = ? ,incluyePatio = ?, incluyePiscina = ? WHERE id_ambiente = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1,ambiente.getNombre());
            sentencia_sql.setBoolean(2,ambiente.isIncluyeMuebles());
            sentencia_sql.setBoolean(3,ambiente.isIncluyeVentana());
            sentencia_sql.setBoolean(4,ambiente.isIncluyePatio());
            sentencia_sql.setBoolean(5,ambiente.isIncluyePiscina());
            sentencia_sql.executeUpdate();
            
            System.out.println("Datos actualizados exitosamente");
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Ambiente actualizado exitosamente");
        
        
    }

    public ArrayList<Ambiente> buscar(int dni_buscado){
        ArrayList<Ambiente> ambientes = new ArrayList<>();
        String consulta_sql = "SELECT * FROM ambientes WHERE dni = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, dni_buscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();
            
            while(resultado_sql.next()){
                Ambiente ambiente = new Ambiente("",true,true,true,true);
                ambiente.setId_ambiente(resultado_sql.getInt("id_propietario"));
                ambiente.setNombre(resultado_sql.getString("nombre"));
                ambiente.setIncluyeMuebles(resultado_sql.getBoolean("incluyeMuebles"));
                ambiente.setIncluyeVentana(resultado_sql.getBoolean("incluyeVentana"));
                ambiente.setIncluyePatio(resultado_sql.getBoolean("incluyePatio"));
                ambiente.setIncluyePiscina(resultado_sql.getBoolean("incluyePiscina"));
 
                ambientes.add(ambiente);
            }
        }catch(SQLException ex){
            
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        }
    
        return ambientes;

    }
/*/
}