package remax.grupo3;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class TurnoDAO {
    
     public ArrayList<Turno> listarporidagente(int id_agente) {
        ArrayList<Turno> lista_turno= new ArrayList<>();

        String consulta_sql = "call mostrarTurnosIdAgente(?)";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
                sentencia_sql.setInt(1, id_agente);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Turno turno = new Turno("","","","","","","");
                turno.setId_turno(resultado.getInt("id_turno"));
                turno.setDireccion(resultado.getString("direccion"));
                turno.setUbicacion(resultado.getString("ubicacion"));
                turno.setHora_turno(resultado.getString("hora_turno"));
                turno.setFecha_turno(resultado.getString("fecha_turno"));
                turno.setCliente(resultado.getString("cliente"));
                turno.setNotas_adicionales(resultado.getString("notas_adicionales"));
                turno.setEstado(resultado.getString("estado"));
                lista_turno.add(turno);
                System.out.println("~~~~~~~~~~~~~");

            }
         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
        }
        return lista_turno;
    }
    
    
    
    
    
    
    
    
    
    /*/
    public void insertar(Turno t) {
        String consulta_sql = "INSERT INTO Turnos Values(default,?,?,?,?,?,?,?)";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
             sentencia_sql.setInt(1, t.getId_());
            sentencia_sql.setString(2, t.getFecha_turno());
            sentencia_sql.setInt(3, t.getHora_turno());
            sentencia_sql.setString(4, t.getNotas_adicionales());
            sentencia_sql.setString(5, t.getEstado());
            

            sentencia_sql.executeUpdate();

          

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
        }
         JOptionPane.showMessageDialog(null,"Turno guardado exitosamente");
    }
    
   
     public ArrayList<Turno> listar() {
        ArrayList<Turno> lista_turno= new ArrayList<>();

        String consulta_sql = "INSERT INTO Turnos Values(default,?,?,?,?,?,?,?)";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);

            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Turno turno = new Turno(1,1,1,"","","","");
                turno.setId_cliente(resultado.getInt("id_cliente"));
                turno.setId_agente(resultado.getInt("id_agente"));
                turno.setId_propiedad(resultado.getInt("id_propiedad"));
                turno.setFecha_turno(resultado.getString("fecha_turno"));
                turno.setHora_turno(resultado.getString("hora_turno"));
                turno.setNotas_adicionales(resultado.getString("notas_adicionales"));
                turno.setEstado(resultado.getString("estado"));
                lista_turno.add(turno);
                System.out.println("~~~~~~~~~~~~~");

            }
         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
        }
        return lista_turno;
    }
    
    
     public void actualizar(Turno t) {

    String consulta_sql = "update turno ";

        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setInt(1, t.getId_cliente());
            sentencia_sql.setInt(2, t.getId_agente());
            sentencia_sql.setInt(3, t.getId_propiedad());
            sentencia_sql.setInt(4, t.getFecha_turno());
            sentencia_sql.setInt(5, t.getHora_turno());
            sentencia_sql.setString(6, t.getNotas_adicionales());
            sentencia_sql.setString(7, t.getEstado());
            

            sentencia_sql.executeUpdate();

            } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
            }
    JOptionPane.showMessageDialog(null,"Turno actualizado exitosamente");
}
     
     public void eliminar(int id) {
        String consulta_sql = "INSERT INTO Turnos Values(?)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id);
            sentencia_sql.executeUpdate();
           

         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        }
         JOptionPane.showMessageDialog(null,"Turno eliminado correctamente ");
    }
     
public ArrayList<Turno> buscarPorId(int id_agente) {
        ArrayList<Turno> turnos = new ArrayList<>();
        String consulta_sql = "INSERT INTO Turnos Values(?)";
        try {
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id_agente);
            ResultSet resultado = sentencia_sql.executeQuery();

            while (resultado.next()) {
                Turno turno = new Turno(1,1,1,1,1,"","");
                turno.setId_cliente(resultado.getInt("id_cliente"));
                turno.setId_agente(resultado.getInt("id_agente"));
                turno.setId_propiedad(resultado.getInt("id_propiedad"));
                turno.setFecha_turno(resultado.getInt("fecha_turno"));
                turno.setHora_turno(resultado.getInt("hora_turno"));
                turno.setNotas_adicionales(resultado.getString("notas_adicionales"));
                turno.setEstado(resultado.getString("estado"));
                turnos.add(turno);
                System.out.println("~~~~~~~~~~~~~");

            }
         } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        } 
        return turnos;
    }
 /*/
}
