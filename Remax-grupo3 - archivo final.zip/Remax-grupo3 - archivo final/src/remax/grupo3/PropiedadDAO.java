package remax.grupo3;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
public class PropiedadDAO {
    public void insertar(Propiedad propiedad){
    String consulta_sql = "call agregarPropiedad(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    
    try{
    Connection conexion= Conexion.conectar();
     PreparedStatement sentencia_sql= conexion.prepareStatement(consulta_sql);
     
     sentencia_sql.setString(1,propiedad.getTipoPropiedad());
     sentencia_sql.setString(2,propiedad.getUbicacion());
     sentencia_sql.setString(3,propiedad.getDireccion());
     sentencia_sql.setInt(4,propiedad.getPrecio());
     sentencia_sql.setString(5,propiedad.getDescripcion());
     sentencia_sql.setInt(6,propiedad.getMetrosCuadrados());
     sentencia_sql.setInt(7,propiedad.getAntiguedad());
     sentencia_sql.setInt(8,propiedad.getReseña());
     sentencia_sql.setInt(9,propiedad.getExpensasMensuales());
     sentencia_sql.setInt(10,propiedad.getPiso());
     sentencia_sql.setString(11,propiedad.getLetraDep());
     sentencia_sql.setBoolean(12,propiedad.isEnConstruccion());
     sentencia_sql.setInt(13,propiedad.getId_propietario());
     
     
    sentencia_sql.executeUpdate();
            
} catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
    
   
        JOptionPane.showMessageDialog(null,"Propiedad insertada exitosamente");
}

public ArrayList<Propiedad> listar() {
       ArrayList<Propiedad>lista_propiedades = new ArrayList<>();
       String consulta_sql ="call mostrarPropiedades()";
       try{
           Connection conexion = Conexion.conectar();
           PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
           //sentencia_sql.setInt(1,dni_buscado);
           ResultSet resultado= sentencia_sql.executeQuery();
           while (resultado.next()){
               Propiedad propiedad = new Propiedad("s","a","a",1,"a",1,1,1,1,1,"a",true,1);
               propiedad.setId_propiedad(resultado.getInt("id_propiedad"));
               propiedad.setTipoPropiedad(resultado.getString("tipoPropiedad"));
               propiedad.setUbicacion(resultado.getString("ubicacion"));
               propiedad.setDireccion(resultado.getString("direccion"));
               propiedad.setPrecio(resultado.getInt("precio"));
               propiedad.setDescripcion(resultado.getString("descripcion"));
               propiedad.setMetrosCuadrados(resultado.getInt("metrosCuadrados"));
               propiedad.setAntiguedad(resultado.getInt("antiguedad"));
               propiedad.setReseña(resultado.getInt("reseña"));
               propiedad.setExpensasMensuales(resultado.getInt("expensasMensuales"));
               propiedad.setPiso(resultado.getInt("piso"));
               propiedad.setLetraDep(resultado.getString("letraDep"));
               propiedad.setEnConstruccion(resultado.getBoolean("enConstruccion"));
               propiedad.setId_propietario(resultado.getInt("id_propietario"));
                     
               lista_propiedades.add(propiedad);
               
           }
           
       }catch (SQLException ex){
           System.out.println("ERROR: " + ex.getMessage());
       }
       return lista_propiedades;
    }

public void eliminar(int id_propiedad){
        String consulta_sql = "call eliminarPropiedad(?)";
  
  
        try {
            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id_propiedad);
            sentencia_sql.executeUpdate();
            
            
           
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Propiedad eliminado exitosamente");
    }

public void actualizar(Propiedad propiedad){
        String consulta_sql = "call actualizarPropiedad(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1,propiedad.getTipoPropiedad());
            sentencia_sql.setString(2,propiedad.getUbicacion());
            sentencia_sql.setString(3,propiedad.getDireccion());
            sentencia_sql.setInt(4,propiedad.getPrecio());
            sentencia_sql.setString(5,propiedad.getDescripcion());
            sentencia_sql.setInt(6,propiedad.getMetrosCuadrados());
            sentencia_sql.setInt(7,propiedad.getAntiguedad());
            sentencia_sql.setInt(8,propiedad.getReseña());
            sentencia_sql.setInt(9,propiedad.getExpensasMensuales());
            sentencia_sql.setInt(10,propiedad.getPiso());
            sentencia_sql.setString(11,propiedad.getLetraDep());
            sentencia_sql.setBoolean(12,propiedad.isEnConstruccion());
            sentencia_sql.setInt(13,propiedad.getId_propietario());
            sentencia_sql.setInt(14,propiedad.getId_propiedad());
            sentencia_sql.executeUpdate();
            
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Propiedad actualizada exitosamente");
        
        
    }

    public ArrayList<Propiedad> buscar(int id_buscado){
        ArrayList<Propiedad> propiedades = new ArrayList<>();
        String consulta_sql = "call buscarPropiedadId(?)";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id_buscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();
            
            while(resultado_sql.next()){
                Propiedad propiedad = new Propiedad("s","a","a",1,"a",1,1,1,1,1,"a",true,1);
               propiedad.setId_propiedad(resultado_sql.getInt("id_propiedad"));
               propiedad.setTipoPropiedad(resultado_sql.getString("tipoPropiedad"));
               propiedad.setUbicacion(resultado_sql.getString("ubicacion"));
               propiedad.setDireccion(resultado_sql.getString("direccion"));
               propiedad.setPrecio(resultado_sql.getInt("precio"));
               propiedad.setDescripcion(resultado_sql.getString("descripcion"));
               propiedad.setMetrosCuadrados(resultado_sql.getInt("metrosCuadrados"));
               propiedad.setAntiguedad(resultado_sql.getInt("antiguedad"));
               propiedad.setReseña(resultado_sql.getInt("reseña"));
               propiedad.setExpensasMensuales(resultado_sql.getInt("expensasMensuales"));
               propiedad.setPiso(resultado_sql.getInt("piso"));
               propiedad.setLetraDep(resultado_sql.getString("letraDep"));
               propiedad.setEnConstruccion(resultado_sql.getBoolean("enConstruccion"));
               propiedad.setId_propietario(resultado_sql.getInt("id_propietario"));
                
                propiedades.add(propiedad);
            }
        }catch(SQLException ex){
            
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        }
    
        return propiedades;

    }
}


