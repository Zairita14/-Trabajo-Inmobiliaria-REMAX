/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remax.grupo3;

import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class VentanaPropiedadesBKR extends javax.swing.JFrame {
    
    public VentanaPropiedadesBKR() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        boxTipoPropiedad = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablePropiedad = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaAmbientesPropiedad = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtUbicacion = new javax.swing.JTextField();
        txtDireccion = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtDescripcion = new javax.swing.JTextField();
        txtMetrosCuadrados = new javax.swing.JTextField();
        txtAntiguedad = new javax.swing.JTextField();
        txtReseña = new javax.swing.JTextField();
        txtExpensasMensuales = new javax.swing.JTextField();
        txtPiso = new javax.swing.JTextField();
        txtLetraDep = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        txtBuscar_id = new javax.swing.JTextField();
        chkEnConstruccion = new javax.swing.JCheckBox();
        jScrollPane4 = new javax.swing.JScrollPane();
        tablaPropietarioPropiedad = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtId_propietario = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        tablaPropietarios = new javax.swing.JTable();
        btnAgregarAmbientes = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(30, 117, 20));

        boxTipoPropiedad.setFont(new java.awt.Font("Sitka Text", 3, 12)); // NOI18N
        boxTipoPropiedad.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PH", "Casa", "Quinta", "Terreno", "Ofecina", "Departamento" }));
        boxTipoPropiedad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxTipoPropiedadActionPerformed(evt);
            }
        });

        TablePropiedad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Tipo propiedad", "Ubicacion", "Direccion", "Precio", "Descripcion", "Metros cuadrados", "Antiguedad", "Reseña", "Expensas mensuales", "Piso", "Letra departamento", "En Construccion"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, true, true, true, true, true, true, true, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablePropiedad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablePropiedadMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TablePropiedad);

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Ambientes de la Propiedad");

        jLabel2.setFont(new java.awt.Font("Tw Cen MT", 3, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Propiedades");

        tablaAmbientesPropiedad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Muebles?", "Ventana?", "Patio?", "Piscina?"
            }
        ));
        jScrollPane3.setViewportView(tablaAmbientesPropiedad);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tipo de propiedad:");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Ubicacion:");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Direccion:");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Precio:");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Descripcion:");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Metros cuadrados");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Antiguedad:");

        jLabel10.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Reseña:");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Expensas mensuales:");

        jLabel12.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Piso:");

        jLabel13.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Letra departamento:");

        jLabel14.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("En construccion:");

        btnAgregar.setForeground(new java.awt.Color(50, 50, 50));
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnMostrar.setForeground(new java.awt.Color(50, 50, 50));
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEditar.setForeground(new java.awt.Color(50, 50, 50));
        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnEliminar.setForeground(new java.awt.Color(50, 50, 50));
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnBuscar.setText("Buscar por Id de propiedad");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        chkEnConstruccion.setBackground(new java.awt.Color(30, 117, 20));
        chkEnConstruccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkEnConstruccionActionPerformed(evt);
            }
        });

        tablaPropietarioPropiedad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Nombre", "Apellido", "DNI"
            }
        ));
        jScrollPane4.setViewportView(tablaPropietarioPropiedad);

        jLabel15.setFont(new java.awt.Font("Tw Cen MT", 3, 36)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Propietario");

        jLabel16.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N

        jLabel17.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Id del propietario");

        tablaPropietarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Apellido", "DNI"
            }
        ));
        tablaPropietarios.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                tablaPropietariosComponentShown(evt);
            }
        });
        jScrollPane5.setViewportView(tablaPropietarios);

        btnAgregarAmbientes.setForeground(new java.awt.Color(50, 50, 50));
        btnAgregarAmbientes.setText("Editar Ambientes de la Propiedad");
        btnAgregarAmbientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarAmbientesActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Propietarios disponibles (como guía):");

        jButton1.setText("Volver");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtUbicacion))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtDireccion))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtAntiguedad, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtReseña, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(10, 10, 10))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDescripcion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(boxTipoPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtPiso, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtLetraDep))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtExpensasMensuales, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtMetrosCuadrados, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(chkEnConstruccion)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtId_propietario, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jLabel18))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel16))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1074, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(btnEditar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(btnEliminar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(btnAgregar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(2, 2, 2)
                                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel15))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1)
                                            .addComponent(btnAgregarAmbientes, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 523, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtBuscar_id, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 39, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(boxTipoPropiedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel4))
                            .addComponent(txtUbicacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(txtDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(txtMetrosCuadrados, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(txtAntiguedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtReseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(txtExpensasMensuales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel12)
                                    .addComponent(txtPiso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13)
                                    .addComponent(txtLetraDep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel17)
                                        .addComponent(txtId_propietario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(chkEnConstruccion)
                                        .addComponent(jLabel14))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtBuscar_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel18)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnAgregarAmbientes, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(btnAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnMostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel16)))
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    
    
    
    
    
    
    private void boxTipoPropiedadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxTipoPropiedadActionPerformed
        
    }//GEN-LAST:event_boxTipoPropiedadActionPerformed

    private void mostrarEnTabla(){
              PropiedadDAO dao = new PropiedadDAO();
        ArrayList <Propiedad> lista_propiedades = dao.listar();
        DefaultTableModel modelo =(DefaultTableModel)TablePropiedad.getModel();
        
        modelo.setRowCount(0);
        
        for (Propiedad propiedad : lista_propiedades){
            modelo.addRow(new Object[]{
                propiedad.getId_propiedad(),
                propiedad.getTipoPropiedad(),
                propiedad.getUbicacion(),
                propiedad.getDireccion(),
                propiedad.getPrecio(),
                propiedad.getDescripcion(),
                propiedad.getMetrosCuadrados(),
                propiedad.getAntiguedad(),
                propiedad.getReseña(),
                propiedad.getExpensasMensuales(),
                propiedad.getPiso(),
                propiedad.getLetraDep(),
                propiedad.isEnConstruccion()
            });
        }
        
        
        
        
        
    }
    
    public void limpiar(){
         boxTipoPropiedad.setSelectedIndex(0);
        txtUbicacion.setText("");
        txtDireccion.setText("");
        txtPrecio.setText("");
        txtDescripcion.setText("");
        txtMetrosCuadrados.setText("");
        txtAntiguedad.setText("");
        txtReseña.setText("");
        txtExpensasMensuales.setText("");
        txtPiso.setText("");
        txtLetraDep.setText("");
        chkEnConstruccion.setSelected(false);
        txtId_propietario.setText("");
    }
    
    private void actualizarTablasAmbientesPropietarios(){
        
        int fila = TablePropiedad.getSelectedRow();
       
        System.out.println("Fila seleccionada: " + fila);
        int id= (int) TablePropiedad.getValueAt(fila,0);
    
        PropiedadDAO dao1 = new PropiedadDAO();
        
        ArrayList<Propiedad> propiedadbuscada = dao1.buscar(id);
        int idpropietario = propiedadbuscada.get(0).getId_propietario();
      
        PropietarioDAO dao2 = new PropietarioDAO();
        
        ArrayList <Propietario> propietarios = dao2.buscarPorId(idpropietario);
        Propietario buscado = propietarios.get(0);
        
        DefaultTableModel modelo2 = (DefaultTableModel)tablaPropietarioPropiedad.getModel();
        
        modelo2.setRowCount(0);
                modelo2.addRow(new Object[]{
                 buscado.getId_propietario(),
                buscado.getNombre(),
                buscado.getApellido()
            });    
      
                
       AmbienteDAO dao3 = new AmbienteDAO();
        ArrayList<Ambiente> lista = dao3.listarPorIdPropiedad(id);
          DefaultTableModel modelo3 = (DefaultTableModel)tablaAmbientesPropiedad.getModel();
        modelo3.setRowCount(0);
           

        for (Ambiente ambiente : lista){
         
                    modelo3.addRow(new Object[]{
                        ambiente.getId_ambiente(),
                        ambiente.getNombre(),
                        ambiente.isIncluyeMuebles(),
                        ambiente.isIncluyeVentana(),  
                        ambiente.isIncluyePatio(),
                        ambiente.isIncluyePiscina()
                });

        }
        
    }
    
    
    
    
    
    
    
    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        
        try{
        String tipo_propiedad = boxTipoPropiedad.getSelectedItem().toString();
        String ubicacion = txtUbicacion.getText();
        String direccion = txtDireccion.getText();
        String precio = txtPrecio.getText();
        String descripcion = txtDescripcion.getText();
        String metrosCuadrados = txtMetrosCuadrados.getText();
        String antiguedad = txtAntiguedad.getText();
        String reseña = txtReseña.getText();
        String expensasMensuales = txtExpensasMensuales.getText();
        String piso = txtPiso.getText();
        String letraDep = txtLetraDep.getText();
        boolean enConstruccion =chkEnConstruccion.isSelected();  
        
             
        int precionumero = Integer.parseInt(precio);
        int antiguedadnumero = Integer.parseInt(antiguedad);
        int metrosCuadradosnum = Integer.parseInt(txtMetrosCuadrados.getText());
        int reseñanumero = Integer.parseInt(reseña);
        int expensasmensualesnum = Integer.parseInt(expensasMensuales);
        int pisonum = Integer.parseInt(piso);
        int id_propietario = Integer.parseInt(txtId_propietario.getText());
        
        if (precionumero < 1){
            
            JOptionPane.showMessageDialog(null,"ERROR: El precio de la propiedad no puede ser menor a 1");
            return;
        }
        
        if (Integer.toString(id_propietario).length() == 0){
            
            JOptionPane.showMessageDialog(null,"ERROR: No hay una id de propietario escrita en el campo");
            return;
        }
        
         if ( reseñanumero < 1 || reseñanumero > 10){
            
            JOptionPane.showMessageDialog(null,"ERROR: La reseña debe puntuarse entre 1-10");
            return;
        }
        
           if ( letraDep.length() != 1 || !letraDep.matches("[a-zA-Z]+") ){
            
            JOptionPane.showMessageDialog(null,"ERROR: La propiedad debe tener solo 1 caractér de letra en el campo Letra de Departamento y debe ser una letra");
            return;
        }
         if ( antiguedadnumero < 0 ){
            
            JOptionPane.showMessageDialog(null,"ERROR: La antiguedad no puede ser negativa!");
            return;
        }
        
        
        
        
        
        
        PropiedadDAO dao = new PropiedadDAO();
        Propiedad propiedad = new Propiedad(tipo_propiedad,ubicacion,direccion,precionumero,descripcion,metrosCuadradosnum,antiguedadnumero,reseñanumero,expensasmensualesnum,pisonum,letraDep,enConstruccion,id_propietario);
        
        
        
        dao.insertar(propiedad);
         
        
     } catch (NumberFormatException ex){
            JOptionPane.showMessageDialog(null,"ERROR: Hay algún campo vacío o uno de los campos tiene un tipo de dato erroneo");
            return;
     }
              mostrarEnTabla();
              limpiar();
      
               
      
   
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
      mostrarEnTabla();
      limpiar();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        try{
            
        int fila = TablePropiedad.getSelectedRow();
        if (fila == -1){
            System.out.println("Debe seleccionar a un propiedad");
            return;
        }
        
        int id = (int) TablePropiedad.getValueAt(fila,0);
        String tipo_propiedad = boxTipoPropiedad.getSelectedItem().toString();
        String ubicacion = txtUbicacion.getText();
        String direccion = txtDireccion.getText();
        String precio = txtPrecio.getText();
        String descripcion = txtDescripcion.getText();
        String metrosCuadrados = txtMetrosCuadrados.getText();
        String antiguedad = txtAntiguedad.getText();
        String reseña = txtReseña.getText();
        String expensasMensuales = txtExpensasMensuales.getText();
        String piso = txtPiso.getText();
        String letraDep = txtLetraDep.getText();
        boolean enConstruccion = chkEnConstruccion.isSelected();
       int id_propietario = Integer.parseInt(txtId_propietario.getText());
        
        int precionumero = Integer.parseInt(precio);
        int metroscuadradonum = Integer.parseInt(metrosCuadrados);
        int antiguedadnumero = Integer.parseInt(antiguedad);
        int reseñanumero = Integer.parseInt(reseña);
        int expensasmensualesnum = Integer.parseInt(expensasMensuales);
        int pisonum = Integer.parseInt(piso);
        
         if (precionumero < 1){
            
            JOptionPane.showMessageDialog(null,"ERROR: El precio de la propiedad no puede ser menor a 1");
            return;
        }
        
        if (Integer.toString(id_propietario).length() == 0){
            
            JOptionPane.showMessageDialog(null,"ERROR: No hay una id de propietario escrita en el campo");
            return;
        }
        
         if ( reseñanumero < 1 || reseñanumero > 10){
            
            JOptionPane.showMessageDialog(null,"ERROR: La reseña debe puntuarse entre 1-10");
            return;
        }
        
           if ( letraDep.length() != 1 || !letraDep.matches("[a-zA-Z]+") ){
            
            JOptionPane.showMessageDialog(null,"ERROR: La propiedad debe tener solo 1 caractér de letra en el campo Letra de Departamento y debe ser una letra");
            return;
        }
         if ( antiguedadnumero < 0 ){
            
            JOptionPane.showMessageDialog(null,"ERROR: La antiguedad no puede ser negativa!");
            return;
        }
        
        
        
        Propiedad propiedad = new Propiedad("","","",1,"",1,1,1,1,1,"",true,1);
        propiedad.setId_propiedad(id);
        propiedad.setTipoPropiedad(tipo_propiedad);
        propiedad.setUbicacion(ubicacion);
        propiedad.setDireccion(direccion);
        propiedad.setPrecio(precionumero);
        propiedad.setDescripcion(descripcion);
        propiedad.setMetrosCuadrados(metroscuadradonum);
        propiedad.setAntiguedad(antiguedadnumero);
        propiedad.setReseña(reseñanumero);
        propiedad.setExpensasMensuales(expensasmensualesnum);
        propiedad.setPiso(pisonum);
        propiedad.setLetraDep(letraDep);
        propiedad.setEnConstruccion(enConstruccion);
        propiedad.setId_propietario(id_propietario);
        PropiedadDAO dao = new PropiedadDAO();
        
        
        
        dao.actualizar(propiedad);
        } catch (NumberFormatException ex){
            JOptionPane.showMessageDialog(null,"ERROR: Hay algún campo vacío o uno de los campos tiene un tipo de dato erroneo");
            return;
        }
        actualizarTablasAmbientesPropietarios();
        mostrarEnTabla();
        
        limpiar();
        
        
        
    }//GEN-LAST:event_btnEditarActionPerformed

    
    
    
    
    
    
    
    private void chkEnConstruccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkEnConstruccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkEnConstruccionActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int fila = TablePropiedad.getSelectedRow();
        
        if(fila == -1){
            System.out.println("Debe seleccionar una propiedad");
            return;
        }
        
        int id = (int)TablePropiedad.getValueAt(fila, 0);
        
        PropiedadDAO dao = new PropiedadDAO();
        
        dao.eliminar(id);
        
        mostrarEnTabla();
        
        limpiar();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
      
      limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        int id = Integer.parseInt(txtBuscar_id.getText());
        
        PropiedadDAO dao = new PropiedadDAO();
        
        ArrayList<Propiedad> propiedades = dao.buscar(id);
        
        DefaultTableModel modelo = (DefaultTableModel)TablePropiedad.getModel();
        
        modelo.setRowCount(0);
        
        for (Propiedad propiedad : propiedades){
                modelo.addRow(new Object[]{
                 propiedad.getId_propiedad(),
                propiedad.getUbicacion(),
                propiedad.getDireccion(),
                propiedad.getPrecio(),
                propiedad.getDescripcion(),
                propiedad.getMetrosCuadrados(),
                propiedad.getAntiguedad(),
                propiedad.getReseña(),
                propiedad.getExpensasMensuales(),
                propiedad.getPiso(),
                propiedad.getLetraDep(),
                propiedad.isEnConstruccion()
            });
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void TablePropiedadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablePropiedadMouseClicked
        
        int fila = TablePropiedad.getSelectedRow();
       
        System.out.println("Fila seleccionada: " + fila);
        int id= (int) TablePropiedad.getValueAt(fila,0);
    
        PropiedadDAO dao1 = new PropiedadDAO();
        
        ArrayList<Propiedad> propiedadbuscada = dao1.buscar(id);
        int idpropietario = propiedadbuscada.get(0).getId_propietario();
      
        PropietarioDAO dao2 = new PropietarioDAO();
        
        ArrayList <Propietario> propietarios = dao2.buscarPorId(idpropietario);
        Propietario buscado = propietarios.get(0);
        
        DefaultTableModel modelo2 = (DefaultTableModel)tablaPropietarioPropiedad.getModel();
        
        modelo2.setRowCount(0);
                modelo2.addRow(new Object[]{
                 buscado.getId_propietario(),
                buscado.getNombre(),
                buscado.getApellido()
            });    
      
                
       AmbienteDAO dao3 = new AmbienteDAO();
        ArrayList<Ambiente> lista = dao3.listarPorIdPropiedad(id);
          DefaultTableModel modelo3 = (DefaultTableModel)tablaAmbientesPropiedad.getModel();
        modelo3.setRowCount(0);
           

        for (Ambiente ambiente : lista){
         
                    modelo3.addRow(new Object[]{
                        ambiente.getId_ambiente(),
                        ambiente.getNombre(),
                        ambiente.isIncluyeMuebles(),
                        ambiente.isIncluyeVentana(),  
                        ambiente.isIncluyePatio(),
                        ambiente.isIncluyePiscina()
                });

        }
        
        
        Propiedad buscada = propiedadbuscada.get(0);
        
        String tipoPropiedad = buscada.getTipoPropiedad();
         String ubicacion = buscada.getUbicacion();
        String direccion = buscada.getUbicacion();
       
        String precio = Integer.toString(buscada.getPrecio());
        String descripcion = buscada.getDescripcion();
        String m2 = Integer.toString(buscada.getMetrosCuadrados());
        String antiguedad = Integer.toString(buscada.getMetrosCuadrados());
        String reseña  = Integer.toString(buscada.getReseña());
        String expensasMensuales = Integer.toString(buscada.getExpensasMensuales());
        String piso = Integer.toString(buscada.getPiso());
        String letraDep = buscada.getLetraDep();
        String id_propietario = Integer.toString(buscada.getId_propietario());
          boxTipoPropiedad.setSelectedItem(tipoPropiedad);
        txtUbicacion.setText(ubicacion);
        txtDireccion.setText(direccion);
        txtPrecio.setText(precio);
        txtDescripcion.setText(descripcion);
        txtMetrosCuadrados.setText(m2);
        txtAntiguedad.setText(antiguedad);
        txtReseña.setText(reseña);
        txtExpensasMensuales.setText(expensasMensuales);
        txtPiso.setText(piso);
        txtLetraDep.setText(letraDep);
        txtId_propietario.setText(id_propietario);
        chkEnConstruccion.setSelected(buscada.isEnConstruccion());
        
        
        
        
        
    }//GEN-LAST:event_TablePropiedadMouseClicked

    private void btnAgregarAmbientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarAmbientesActionPerformed
     int fila = TablePropiedad.getSelectedRow();
        
        if(fila == -1){
            System.out.println("Debe seleccionar una propiedad");
            return;
        }
        
        int id = (int)TablePropiedad.getValueAt(fila, 0);
        
        
        VentanaPropiedadAmbientesBKR vpa = new VentanaPropiedadAmbientesBKR(id, this);
       vpa.setVisible(true);
       this.setVisible(false);
        
        
        
        
    }//GEN-LAST:event_btnAgregarAmbientesActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        mostrarEnTabla();    
        
  PropietarioDAO dao2 = new PropietarioDAO();
        
        ArrayList <Propietario> propietarios = dao2.listar();
        
        
        DefaultTableModel modelo2 = (DefaultTableModel)tablaPropietarios.getModel();
        
        
        modelo2.setRowCount(0);
        
        
        for (Propietario p : propietarios){
                modelo2.addRow(new Object[]{
                 p.getId_propietario(),
                p.getNombre(),
                p.getApellido(),
                p.getDni()
            });    
        }
        
        
    }//GEN-LAST:event_formComponentShown

    private void tablaPropietariosComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_tablaPropietariosComponentShown
             
        
        
        
        
    }//GEN-LAST:event_tablaPropietariosComponentShown

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       VentanaOpcionesBroker vob = new VentanaOpcionesBroker();
       vob.setVisible(true);
       this.setVisible(false);
              

    }//GEN-LAST:event_jButton1ActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedadesBKR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedadesBKR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedadesBKR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPropiedadesBKR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new VentanaPropiedadesAGT().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TablePropiedad;
    private javax.swing.JComboBox<String> boxTipoPropiedad;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnAgregarAmbientes;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JCheckBox chkEnConstruccion;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable tablaAmbientesPropiedad;
    private javax.swing.JTable tablaPropietarioPropiedad;
    private javax.swing.JTable tablaPropietarios;
    private javax.swing.JTextField txtAntiguedad;
    private javax.swing.JTextField txtBuscar_id;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtDireccion;
    private javax.swing.JTextField txtExpensasMensuales;
    private javax.swing.JTextField txtId_propietario;
    private javax.swing.JTextField txtLetraDep;
    private javax.swing.JTextField txtMetrosCuadrados;
    private javax.swing.JTextField txtPiso;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtReseña;
    private javax.swing.JTextField txtUbicacion;
    // End of variables declaration//GEN-END:variables
}
