package remax.grupo3;


public class Turno {
    private int id_turno;
    private String direccion;
    private String ubicacion;
    private String hora_turno;
    private String fecha_turno;
    private String cliente;
    private String estado;
    private String notas_adicionales;

    public Turno(String direccion, String ubicacion, String hora_turno, String fecha_turno, String cliente, String estado, String notas_adicionales) {
        this.direccion = direccion;
        this.ubicacion = ubicacion;
        this.hora_turno = hora_turno;
        this.fecha_turno = fecha_turno;
        this.cliente = cliente;
        this.estado = estado;
        this.notas_adicionales = notas_adicionales;
    }

    public int getId_turno() {
        return id_turno;
    }

    public void setId_turno(int id_turno) {
        this.id_turno = id_turno;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getHora_turno() {
        return hora_turno;
    }

    public void setHora_turno(String hora_turno) {
        this.hora_turno = hora_turno;
    }

    public String getFecha_turno() {
        return fecha_turno;
    }

    public void setFecha_turno(String fecha_turno) {
        this.fecha_turno = fecha_turno;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getNotas_adicionales() {
        return notas_adicionales;
    }

    public void setNotas_adicionales(String notas_adicionales) {
        this.notas_adicionales = notas_adicionales;
    }
    
    
    
    
    
}
