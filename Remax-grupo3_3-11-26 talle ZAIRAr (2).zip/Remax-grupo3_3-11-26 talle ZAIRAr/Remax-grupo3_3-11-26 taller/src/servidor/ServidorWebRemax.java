
package servidor;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServidorWebRemax {

    public static void main(String[] args) throws IOException {

        HttpServer servidor = HttpServer.create(
                new InetSocketAddress(8080), 0
        );

        servidor.createContext("/", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto HTML/CSS: " + ruta);
                Path archivo = null;
                
                  if (ruta.equals("/")) {
                    archivo = Paths.get("src", "Web", "index.html");
                    } else if (ruta.equals("/index.html")){
                     archivo = Paths.get("src", "Web", "/index.html");
                    
                } else if (ruta.equals("/logotipoRemax.webp")){
                     archivo = Paths.get("src", "Web", "logotipoRemax.webp");
                   
                } else if (ruta.equals("/fondo2.jpg")){
                    archivo = Paths.get("src", "Web", "fondo2.jpg");
                    
                } else if (ruta.equals("/registrar.html")){
                    archivo = Paths.get("src", "Web", "registrar.html");
                    
                  } else if (ruta.equals("/iniciarsesion.html")){
                    archivo = Paths.get("src", "Web", "iniciarsesion.html");
                    
                } else if (ruta.equals("/propiedades.html")){
                    archivo = Paths.get("src", "Web", "propiedades.html");
                    
                 } else if (ruta.equals("/verpropiedad.html")){
                    archivo = Paths.get("src", "Web", "verpropiedad.html");
                    
                 } else if (ruta.equals("/editar-datosdelcliente.html")){
                    archivo = Paths.get("src", "Web", "editar-datosdelcliente.html");
                    
                } 
                                
                /*/
                
                
                
                
                if (ruta.equals("/")) {
                    archivo = Paths.get("src", "Web", "index.html");
                } else if (ruta.equals("/personas.html")) {
                    archivo = Paths.get("src", "Web", "personas.html");
                } else if (ruta.equals("/estilos.css")) {
                    archivo = Paths.get("src", "Web", "estilos.css");
                }else if(ruta.equals("/nueva-persona.html")){
                    archivo = Paths.get("src", "Web", "nueva-persona.html");
                }else if(ruta.equals("/editar-persona.html")){
                    archivo = Paths.get("src", "Web", "editar-persona.html");
                }
                /*/
                System.out.println("Archivo: " + (archivo != null ? archivo.toAbsolutePath() : "No definido"));

                System.out.println("Existe: " + (archivo != null && Files.exists(archivo)));

                byte[] contenido;
                int codigo;

                if (archivo != null && Files.exists(archivo)) {
                    contenido = Files.readAllBytes(archivo);
                    codigo = 200;
                    if (ruta.equals("/estilos.css")) {
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/css; charset=UTF-8"
                        );

                    }else{
                        intercambio.getResponseHeaders().set(
                                "Content-Type",
                                "text/html; charset=UTF-8"
                        );
                    }
                } else {
                    String mensaje = "Archivo no encontrado";
                    contenido = mensaje.getBytes(
                            StandardCharsets.UTF_8
                    );
                    codigo = 404;
                    intercambio.getResponseHeaders().set(
                            "Content-Type",
                            "text/plain; charset=UTF-8"
                    );
                }
                intercambio.sendResponseHeaders(
                        codigo, contenido.length
                );
                try (OutputStream salida =
                        intercambio.getResponseBody()) {

                    salida.write(contenido);
                }
            }
        });
        
        
        servidor.createContext("/api/propiedades/buscarporid", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }

                // Obtener los valores del formulario.
                String idTexto = datos.get("idBuscada");
                System.out.println("id:" + datos.get("idBuscada"));
                // Validar los campos.
                if (idTexto == null){

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }
                
                /*/
                int idint;
                
                try {
                    idint = Integer.parseInt(idTexto);
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Id invalido\"}");
                    return;
                }
                /*/
                int idint = Integer.parseInt(idTexto);
                // Preparar la consulta SQL.
                      String sql = "select id_propiedad , tipoPropiedad, ubicacion, direccion, precio, expensasMensuales, reseña from Propiedades where id_propiedad = ? limit 1";
                StringBuilder json = new StringBuilder();
                try {
                        
                    Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3308/remax","root","");
                    PreparedStatement sentencia = conexion.prepareStatement(sql);
                    sentencia.setInt(1, idint);
                    ResultSet resultado = sentencia.executeQuery();
                        
                        
               
                    json.append("[");
                    boolean primero = true;
                    while (resultado.next()) {
                        if (!primero) {
                            json.append(",");
                        }
                        json.append("{");
                        json.append("\"id_propiedad\":").append(resultado.getInt("id_propiedad")).append(",");
                        json.append("\"tipoPropiedad\":\"").append(escaparJson(resultado.getString("tipoPropiedad"))).append("\",");
                        json.append("\"ubicacion\":\"").append(escaparJson(resultado.getString("ubicacion"))).append("\",");
                        json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
                        json.append("\"precio\":").append(resultado.getInt("precio")).append(",");
                        json.append("\"expensasMensuales\":").append(resultado.getInt("expensasMensuales")).append(",");
                        json.append("\"reseña\":").append(resultado.getInt("reseña")).append("");
                        
                        json.append("}");
                        primero = false;
                    }
                    json.append("]");
                    
                    System.out.println(json.toString());
                    enviarRespuesta(intercambio, 200, json.toString());
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos \"}");
                }
            }
        });
 
        
        
        //nehuen editar clientes
        
        servidor.createContext("/api/clientes/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id_Cliente = Integer.parseInt(datos.get("id_cliente"));
                    int dni = Integer.parseInt(datos.get("dni"));
                    int telefono = Integer.parseInt(datos.get("telefono"));
 
                    Boolean  contraseña =Boolean.parseBoolean("contraseña");
                    Boolean  mascotas = Boolean.parseBoolean("mascotas");
                    Boolean hijos= Boolean.parseBoolean("hijos");
                   Boolean recibo_sueldo = Boolean.parseBoolean("recibo_sueldo");

                    
                    String nombre = datos.get("nombre").trim();
                    String apellido = datos.get("apellido").trim();
                    String correo = datos.get("correo").trim();

                    if (id_Cliente <= 0 || dni <= 0 || telefono < 0
                            || nombre.isEmpty() || apellido.isEmpty()
                            || correo.isEmpty() || nombre.length() > 50
                            || apellido.length() > 50 || correo.length() > 100) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE clientes SET nombre = ?, apellido = ?, "
                            + "dni = ?, telefono = ?, correo = ?,contraseña =?,recibo_sueldo=?,mascotas=?.hijos=? WHERE id_cliente = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3308/remax", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {

                        sentencia.setString(1, nombre);
                        sentencia.setString(2, apellido);
                        sentencia.setInt(3, dni);
                        sentencia.setInt(4, telefono);
                        sentencia.setString(5,correo);
                        sentencia.setBoolean(6,contraseña);
                        sentencia.setBoolean(7,recibo_sueldo);
                        sentencia.setBoolean(8,mascotas);
                        sentencia.setBoolean(9,hijos);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Cliente  actualizado correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro el Cliente\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"ID, DNI y telefono deben ser numeros validos\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
       
     
        
        servidor.createContext("/api/propiedades", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto de propiedades: " + ruta);
                if (!ruta.equals("/api/propiedades")) {
                    enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
                    return;
                }
                
                String sql = "select id_propiedad , tipoPropiedad, ubicacion, direccion, precio, expensasMensuales, reseña from Propiedades";
                StringBuilder json = new StringBuilder();
                try (
                    Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3308/remax","root","");
                    PreparedStatement sentencia = conexion.prepareStatement(sql);
                    ResultSet resultado = sentencia.executeQuery()
                ) {
                    json.append("[");
                    boolean primero = true;
                    while (resultado.next()) {
                        if (!primero) {
                            json.append(",");
                        }
                        json.append("{");
                        json.append("\"id_propiedad\":").append(resultado.getInt("id_propiedad")).append(",");
                        json.append("\"tipoPropiedad\":\"").append(escaparJson(resultado.getString("tipoPropiedad"))).append("\",");
                        json.append("\"ubicacion\":\"").append(escaparJson(resultado.getString("ubicacion"))).append("\",");
                        json.append("\"direccion\":\"").append(escaparJson(resultado.getString("direccion"))).append("\",");
                        json.append("\"precio\":").append(resultado.getInt("precio")).append(",");
                        json.append("\"expensasMensuales\":").append(resultado.getInt("expensasMensuales")).append(",");
                        json.append("\"reseña\":").append(resultado.getInt("reseña")).append("");
                        
                        json.append("}");
                        primero = false;
                    }
                    json.append("]");
                    
                    System.out.println(json.toString());
                    enviarRespuesta(intercambio, 200, json.toString());
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos \"}");
                }
            }
        });
        
        
        
        
        
        
   
        
        
        
        
        
        
        
        
      
      
      
      
      
      
      
      
      
      
      
        
        
        
        /*/
        servidor.createContext("/api/personas", new HttpHandler() {
            @Override
            public void handle(HttpExchange intercambio) throws IOException {
                String ruta = intercambio.getRequestURI().getPath();
                System.out.println("Contexto de personas: " + ruta);
                if (!ruta.equals("/api/personas")) {
                    enviarRespuesta(intercambio, 404, "{\"error\":\"Ruta no encontrada\"}");
                    return;
                }
                String sql = "SELECT id, dni, nombre, apellido, edad, correo FROM persona";
                StringBuilder json = new StringBuilder();
                try (
                    Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/personas","root","");
                    PreparedStatement sentencia = conexion.prepareStatement(sql);
                    ResultSet resultado = sentencia.executeQuery()
                ) {
                    json.append("[");
                    boolean primero = true;
                    while (resultado.next()) {
                        if (!primero) {
                            json.append(",");
                        }
                        json.append("{");
                        json.append("\"id\":").append(resultado.getInt("id")).append(",");
                        json.append("\"dni\":").append(resultado.getInt("dni")).append(",");
                        json.append("\"nombre\":\"").append(escaparJson(resultado.getString("nombre"))).append("\",");
                        json.append("\"apellido\":\"").append(escaparJson(resultado.getString("apellido"))).append("\",");
                        json.append("\"edad\":").append(resultado.getInt("edad")).append(",");
                        json.append("\"correo\":\"").append(escaparJson(resultado.getString("correo"))).append("\"");
                        json.append("}");
                        primero = false;
                    }
                    json.append("]");
                    enviarRespuesta(intercambio, 200, json.toString());
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500, "{\"error\":\"Error al consultar la base de datos\"}");
                }
            }
        });
        
        
        servidor.createContext("/api/personas/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }

                // Obtener los valores del formulario.
                String dniTexto = datos.get("dni");
                String nombre = datos.get("nombre");
                String apellido = datos.get("apellido");
                String edadTexto = datos.get("edad");
                String correo = datos.get("correo");

                // Validar los campos.
                if (dniTexto == null || nombre == null
                        || apellido == null || edadTexto == null
                        || correo == null || dniTexto.trim().isEmpty()
                        || nombre.trim().isEmpty()
                        || apellido.trim().isEmpty()
                        || edadTexto.trim().isEmpty()
                        || correo.trim().isEmpty()) {

                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                    return;
                }

                int dni;
                int edad;

                try {
                    dni = Integer.parseInt(dniTexto);
                    edad = Integer.parseInt(edadTexto);
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"DNI y edad deben ser numeros enteros\"}");
                    return;
                }

                // Preparar la consulta SQL.
                String sql = "INSERT INTO persona "
                        + "(dni, nombre, apellido, edad, correo) "
                        + "VALUES (?, ?, ?, ?, ?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/personas",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql)
                ) {
                    sentencia.setInt(1, dni);
                    sentencia.setString(2, nombre.trim());
                    sentencia.setString(3, apellido.trim());
                    sentencia.setInt(4, edad);
                    sentencia.setString(5, correo.trim());

                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Persona guardada correctamente\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar la persona\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });

        /*/
        
       // crear
        servidor.createContext("/api/clientes/crear", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                // Leer los datos que llegan desde el formulario.
                java.io.InputStream entrada = intercambio.getRequestBody();
                java.io.ByteArrayOutputStream buffer =
                        new java.io.ByteArrayOutputStream();

                int dato;
                while ((dato = entrada.read()) != -1) {
                    buffer.write(dato);
                }

                String cuerpo = new String(
                        buffer.toByteArray(),
                        StandardCharsets.UTF_8
                );

                // Separar los datos recibidos.
                java.util.Map<String, String> datos =
                        new java.util.HashMap<String, String>();

                String[] parametros = cuerpo.split("&");

                for (String parametro : parametros) {
                    String[] partes = parametro.split("=", 2);

                    String clave = java.net.URLDecoder.decode(
                            partes[0], "UTF-8"
                    );

                    String valor = "";

                    if (partes.length > 1) {
                        valor = java.net.URLDecoder.decode(
                                partes[1], "UTF-8"
                        );
                    }

                    datos.put(clave, valor);
                }

                System.out.println(datos);
                String nombre = datos.get("nombre");
                String apellido = datos.get("apellido");
                String dniTexto = datos.get("dni");
                String telefonoTexto = datos.get("telefono");
                String email = datos.get("correo");
                String contraseña= datos.get("password");
                String reciboSueldoTexto = datos.get("recibo_sueldo");
                String mascotasTexto = datos.get("mascotas");
                String hijosTexto = datos.get("hijos");
                

                // Validar los campos.
              
               if (nombre == null
                        || apellido == null ||
                        dniTexto == null ||
                        telefonoTexto == null ||
                        email == null ||
                        contraseña == null ||
                        reciboSueldoTexto == null ||
                        mascotasTexto == null ||
                        hijosTexto == null || 
                        nombre.trim().isEmpty()
                        || apellido.trim().isEmpty()
                        || dniTexto.trim().isEmpty()
                        || telefonoTexto.trim().isEmpty()
                        || email.trim().isEmpty()
                        || contraseña.trim().isEmpty()
                        || reciboSueldoTexto.trim().isEmpty()
                        || mascotasTexto.trim().isEmpty()
                        || hijosTexto.trim().isEmpty()
                       ) 
               
               {

                enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Todos los campos son obligatorios\"}");
                return;
                }
             
                int dni;
                int telefono;
               
                boolean reciboSueldo;
                boolean mascotas;
                boolean hijos;
                
                
                    
                    
                try {
                    dni = Integer.parseInt(dniTexto);
                    telefono = Integer.parseInt(telefonoTexto);
                   
                    reciboSueldo = Boolean.parseBoolean(reciboSueldoTexto);
                    mascotas = Boolean.parseBoolean(mascotasTexto);
                    hijos = Boolean.parseBoolean(hijosTexto);
                    
                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"\"}");
                    return;
                }
                   
                // Preparar la consulta SQL.
                String sql = "INSERT INTO Clientes "
                        + "(nombre,apellido,dni,telefono, email, contraseña,recibo_sueldo,mascotas,hijos) "
                        + "VALUES (?, ?, ?, ?, ?,?,?,?,?)";

                try (
                    Connection conexion = DriverManager.getConnection(
                            "jdbc:mysql://localhost:3308/remax",
                            "root",
                            ""
                    );

                    PreparedStatement sentencia =
                            conexion.prepareStatement(sql);
                        ){
                    sentencia.setString(1, nombre);
                    sentencia.setString(2, apellido);
                    sentencia.setInt(3, dni);
                    sentencia.setInt(4, telefono);
                    sentencia.setString(5, email.trim());
                    sentencia.setString(6, contraseña.trim());
                    sentencia.setBoolean(7,reciboSueldo);
                    sentencia.setBoolean(8,mascotas);
                    sentencia.setBoolean(9,hijos);
                  
                
                    int filasInsertadas = sentencia.executeUpdate();

                    if (filasInsertadas > 0) {
                        enviarRespuesta(intercambio, 201,
                                "{\"mensaje\":\"Registro Correcto\"}");
                    } else {
                        enviarRespuesta(intercambio, 500,
                                "{\"error\":\"No se pudo guardar\"}");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();

                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al guardar en la base de datos\"}");
                }
            }
        });

        servidor.createContext("/api/personas/editar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id = Integer.parseInt(datos.get("id"));
                    int dni = Integer.parseInt(datos.get("dni"));
                    int edad = Integer.parseInt(datos.get("edad"));

                    String nombre = datos.get("nombre").trim();
                    String apellido = datos.get("apellido").trim();
                    String correo = datos.get("correo").trim();

                    if (id <= 0 || dni <= 0 || edad < 0
                            || nombre.isEmpty() || apellido.isEmpty()
                            || correo.isEmpty() || nombre.length() > 50
                            || apellido.length() > 50 || correo.length() > 100) {

                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"Revisa los datos ingresados\"}");
                        return;
                    }

                    String sql = "UPDATE persona SET dni = ?, nombre = ?, "
                            + "apellido = ?, edad = ?, correo = ? WHERE id = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/personas", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, dni);
                        sentencia.setString(2, nombre);
                        sentencia.setString(3, apellido);
                        sentencia.setInt(4, edad);
                        sentencia.setString(5, correo);
                        sentencia.setInt(6, id);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Persona actualizada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"ID, DNI y edad deben ser numeros validos\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al actualizar la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"Faltan datos o son invalidos\"}");
                }
            }
        });

        
        
        servidor.createContext("/api/personas/eliminar", new HttpHandler() {

            @Override
            public void handle(HttpExchange intercambio) throws IOException {

                if (!intercambio.getRequestMethod().equals("POST")) {
                    enviarRespuesta(intercambio, 405,
                            "{\"error\":\"Metodo no permitido\"}");
                    return;
                }

                java.util.Map<String, String> datos = leerParametros(intercambio);

                try {
                    int id = Integer.parseInt(datos.get("id"));

                    if (id <= 0) {
                        enviarRespuesta(intercambio, 400,
                                "{\"error\":\"ID no valido\"}");
                        return;
                    }

                    String sql = "DELETE FROM persona WHERE id = ?";

                    try (
                        Connection conexion = DriverManager.getConnection(
                                "jdbc:mysql://localhost:3306/personas", "root", "");
                        PreparedStatement sentencia = conexion.prepareStatement(sql)
                    ) {
                        sentencia.setInt(1, id);

                        int filas = sentencia.executeUpdate();

                        if (filas > 0) {
                            enviarRespuesta(intercambio, 200,
                                    "{\"mensaje\":\"Persona eliminada correctamente\"}");
                        } else {
                            enviarRespuesta(intercambio, 404,
                                    "{\"error\":\"No se encontro la persona\"}");
                        }
                    }

                } catch (NumberFormatException e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"El ID debe ser numerico\"}");
                } catch (SQLException e) {
                    e.printStackTrace();
                    enviarRespuesta(intercambio, 500,
                            "{\"error\":\"Error al eliminar de la base de datos\"}");
                } catch (Exception e) {
                    enviarRespuesta(intercambio, 400,
                            "{\"error\":\"No se pudo procesar la solicitud\"}");
                }
            }
        });

        
        //Iniciamos el servidor
        
        servidor.start();
        System.out.println("Servidor iniciado en http://localhost:8080");
    }
    
    
    
        private static java.util.Map<String, String> leerParametros(
                HttpExchange intercambio) throws IOException {

            java.io.InputStream entrada = intercambio.getRequestBody();

            java.io.ByteArrayOutputStream buffer =
                    new java.io.ByteArrayOutputStream();

            int dato;

            while ((dato = entrada.read()) != -1) {
                buffer.write(dato);
            }

            String cuerpo = new String(
                    buffer.toByteArray(),
                    StandardCharsets.UTF_8
            );

            java.util.Map<String, String> parametros =
                    new java.util.HashMap<String, String>();

            String[] partes = cuerpo.split("&");

            for (String parte : partes) {
                String[] campo = parte.split("=", 2);

                String clave = java.net.URLDecoder.decode(
                        campo[0], "UTF-8"
                );

                String valor = "";

                if (campo.length > 1) {
                    valor = java.net.URLDecoder.decode(
                            campo[1], "UTF-8"
                    );
                }

                parametros.put(clave, valor);
            }

            return parametros;
        }

    
    private static String escaparJson(String texto) {

        if (texto == null) {
            return "";
        }

        return texto
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private static void enviarRespuesta(
            HttpExchange intercambio,
            int codigo,
            String respuesta
    ) throws IOException {

        byte[] contenido = respuesta.getBytes(
                StandardCharsets.UTF_8
        );

        intercambio.getResponseHeaders().set(
                "Content-Type",
                "application/json; charset=UTF-8"
        );

        intercambio.sendResponseHeaders(
                codigo, contenido.length
        );

        try (OutputStream salida =
                intercambio.getResponseBody()) {

            salida.write(contenido);
        }
    }
}




