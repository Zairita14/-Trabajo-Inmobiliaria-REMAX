
package remax.grupo3;

public abstract class Operacion {
    private Propiedad propiedad;
    private Cliente cliente;
    private Agente agente;

    public Operacion(Propiedad propiedad, Cliente cliente, Agente agente) {
        this.propiedad = propiedad;
        this.cliente = cliente;
        this.agente = agente;
    }

    public Propiedad getPropiedad() {
        return propiedad;
    }

    public void setPropiedad(Propiedad propiedad) {
        this.propiedad = propiedad;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Agente getAgente() {
        return agente;
    }

    public void setAgente(Agente agente) {
        this.agente = agente;
    }
    
   public abstract void mostrarOperaciones();
}

