
package remax.grupo3;
import javax.swing.JOptionPane;
public class Alquiler extends Operacion {
    
    private String fecha_inicio;
    private int plazo_meses_alquiler;

    public Alquiler(String fecha_inicio, int plazo_meses_alquiler, Propiedad propiedad, Cliente cliente, Agente agente) {
        super(propiedad, cliente, agente);
        this.fecha_inicio = fecha_inicio;
        this.plazo_meses_alquiler = plazo_meses_alquiler;
    }

   
    

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public int getPlazo_meses_alquiler() {
        return plazo_meses_alquiler;
    }

    public void setPlazo_meses_alquiler(int plazo_meses_alquiler) {
        this.plazo_meses_alquiler = plazo_meses_alquiler;
    }
    
    @Override
    
    public void mostrarOperaciones(){
        JOptionPane.showMessageDialog(null,"Propiedad" + getPropiedad()+ "\n Cliente" + getCliente() + "\n Agente" + getAgente() + "\n Fecha de inicio" + getFecha_inicio() + "\n Plazo de meses" + getPlazo_meses_alquiler());
  
    }
}





