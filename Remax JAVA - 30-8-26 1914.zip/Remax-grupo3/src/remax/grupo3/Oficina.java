
package remax.grupo3;

import javax.swing.JOptionPane;

public class Oficina extends Propiedad {
    private boolean incluyeMuebles;

    public Oficina(boolean incluyeMuebles, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales) {
        super(Ubicacion, Direccion, precio, Descripcion, MetrosCuadrados, Ambiente, CantBaños, Antiguedad, reseña, ExpensasMensuales);
        this.incluyeMuebles = incluyeMuebles;
    }

    public boolean isIncluyeMuebles() {
        return incluyeMuebles;
    }

    public void setIncluyeMuebles(boolean incluyeMuebles) {
        this.incluyeMuebles = incluyeMuebles;
    }
  
    
    @Override
    public void mostrarPropiedad(){
       JOptionPane.showMessageDialog(null,"ubicacion"+Ubicacion+
"\ndireccion"+Direccion+
"\nprecio"+precio+
"\ndescripcion"+Descripcion+
"\nmetros cuadrados"+MetrosCuadrados+
"\nambientes"+Ambiente+
"\ncantidad de baños"+CantBaños+
"\nantiguedad"+Antiguedad+
"\nreseña"+reseña+
"\nexpensasmensuales"+ExpensasMensuales +
"\nincluye muebles" + incluyeMuebles
);
      
    }
}

