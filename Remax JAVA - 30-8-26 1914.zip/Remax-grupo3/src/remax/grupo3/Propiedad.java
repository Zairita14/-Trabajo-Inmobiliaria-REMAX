
package remax.grupo3;

public abstract class Propiedad {
    protected String Ubicacion;
    protected String Direccion;
    protected int precio;
    protected String Descripcion;
    protected double MetrosCuadrados;
    protected int Ambiente;
    protected int CantBaños;
    protected int Antiguedad;
    protected int reseña;
    protected int ExpensasMensuales;

    public Propiedad(String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales) {
        this.Ubicacion = Ubicacion;
        this.Direccion = Direccion;
        this.precio = precio;
        this.Descripcion = Descripcion;
        this.MetrosCuadrados = MetrosCuadrados;
        this.Ambiente = Ambiente;
        this.CantBaños = CantBaños;
        this.Antiguedad = Antiguedad;
        this.reseña = reseña;
        this.ExpensasMensuales = ExpensasMensuales;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String Ubicacion) {
        this.Ubicacion = Ubicacion;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public double getMetrosCuadrados() {
        return MetrosCuadrados;
    }

    public void setMetrosCuadrados(double MetrosCuadrados) {
        this.MetrosCuadrados = MetrosCuadrados;
    }

    public int getAmbiente() {
        return Ambiente;
    }

    public void setAmbiente(int Ambiente) {
        this.Ambiente = Ambiente;
    }

    public int getCantBaños() {
        return CantBaños;
    }

    public void setCantBaños(int CantBaños) {
        this.CantBaños = CantBaños;
    }

    public int getAntiguedad() {
        return Antiguedad;
    }

    public void setAntiguedad(int Antiguedad) {
        this.Antiguedad = Antiguedad;
    }

    public int getReseña() {
        return reseña;
    }

    public void setReseña(int reseña) {
        this.reseña = reseña;
    }

    public int getExpensasMensuales() {
        return ExpensasMensuales;
    }

    public void setExpensasMensuales(int ExpensasMensuales) {
        this.ExpensasMensuales = ExpensasMensuales;
    }
    public abstract void mostrarPropiedad();
}
