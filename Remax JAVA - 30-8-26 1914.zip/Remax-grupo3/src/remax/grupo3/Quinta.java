
package remax.grupo3;

import javax.swing.JOptionPane;
public class Quinta extends Propiedad {
    private boolean incluyePiscina;

    public Quinta(boolean incluyePiscina, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales) {
        super(Ubicacion, Direccion, precio, Descripcion, MetrosCuadrados, Ambiente, CantBaños, Antiguedad, reseña, ExpensasMensuales);
        this.incluyePiscina = incluyePiscina;
    }

    public boolean isIncluyePiscina() {
        return incluyePiscina;
    }

    public void setIncluyePiscina(boolean incluyePiscina) {
        this.incluyePiscina = incluyePiscina;
    }


    
    @Override
    public void mostrarPropiedad(){
    JOptionPane.showMessageDialog(null, "ubicacion"+Ubicacion+
    "\ndireccion"+Direccion+
    "\nprecio"+precio+
    "\ndescripcion"+Descripcion+
    "\nmetros cuadrados"+MetrosCuadrados+
    "\nambientes"+Ambiente+
    "\ncantidad de baños"+CantBaños+
    "\nantiguedad"+Antiguedad+
    "\nreseña"+reseña+
    "\nexpensasmensuales"+ExpensasMensuales+
    "\nincluyePiscina" + incluyePiscina );
    }
}

