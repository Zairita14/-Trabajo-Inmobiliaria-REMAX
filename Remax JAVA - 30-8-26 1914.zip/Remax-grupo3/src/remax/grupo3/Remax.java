
package remax.grupo3;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Remax {
    
    private String nombre;
    private String direccion; 
    private ArrayList<Persona> personas;
    private ArrayList<Propiedad> propiedades;
    private ArrayList<Operacion> operaciones;

    public Remax(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
          personas = new ArrayList<>();
        propiedades = new ArrayList<>();
        operaciones = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    public void setPersonas(ArrayList<Persona> personas) {
        this.personas = personas;
    }

    public ArrayList<Propiedad> getPropiedades() {
        return propiedades;
    }

    public void setPropiedades(ArrayList<Propiedad> propiedades) {
        this.propiedades = propiedades;
    }

    public ArrayList<Operacion> getOperaciones() {
        return operaciones;
    }

    public void setOperaciones(ArrayList<Operacion> operaciones) {
        this.operaciones = operaciones;
    }

    
    
    
    
    
    
    
    
    public void agregarPersona(Persona persona){
    personas.add(persona);
    
    }
    
    public void agregarPropiedad(Propiedad propiedad){
        propiedades.add(propiedad);
    }
    
   public void agregarOperacion(Operacion operacion){
   operaciones.add(operacion);
   } 
   
   public Propiedad buscarpropiedad(String direccion){
   for (Propiedad propiedad : propiedades){
       if (propiedad.getDireccion().equalsIgnoreCase(direccion)){ 
           return propiedad;
       }  
   }
       return null;
   }
   
      public Persona buscarpersona(int dni){
   for (Persona persona : personas){
       if (persona.getDni() == dni){ 
           return persona;
       }  
   }
       return null;
   }
   

   
    
   public void editarPropiedad(String direccion){
   
   Propiedad propiedad = buscarpropiedad(direccion);
   
   
   if (propiedad != null){
        String ubicacion = JOptionPane.showInputDialog("Ingrese su nueva ubicacion actualizada");
        int precio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su nuevo precio actualizado"));
        String descripcion = JOptionPane.showInputDialog("Ingrese su nueva descripción actualizada");
        double m2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su tamaño en metros cuadrados actualizado"));
         int ambientes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad actualizada de ambientes"));
         int baños = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su cantidad de baños actualizada"));
         int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su antiguedad actualizada"));
         int reseña = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su puntuación en promedio de reseñas actualizada "));
         int expensas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus expensas actualizadas "));

         propiedad.setUbicacion(ubicacion);

         propiedad.setPrecio(precio);
         propiedad.setDescripcion(descripcion);
         propiedad.setMetrosCuadrados(m2);
         propiedad.setAmbiente(ambientes);
         propiedad.setCantBaños(baños);
         propiedad.setAntiguedad(antiguedad);
         propiedad.setReseña(reseña);
         propiedad.setExpensasMensuales(expensas);


          if (propiedad instanceof Departamento){
             Departamento departamento = (Departamento)propiedad;
            int piso =  Integer.parseInt(JOptionPane.showInputDialog("Ingrese el piso actualizado" ));
             String letraDep =  JOptionPane.showInputDialog("Ingrese su letra de departamento actualizada" );

             departamento.setPiso(piso);
             departamento.setLetraDep(letraDep);

         }

         if (propiedad instanceof Oficina){
             Oficina oficina = (Oficina)propiedad;
             String opt =  JOptionPane.showInputDialog("Incluye muebles? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 oficina.setIncluyeMuebles(true);

             } else {
                 oficina.setIncluyeMuebles(false);

             }

         }

         if (propiedad instanceof PH){
              PH ph= (PH)propiedad;
             String opt =  JOptionPane.showInputDialog("Incluye ventana? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 ph.setIncluyeVentana(true);

             } else {
                 ph.setIncluyeVentana(false);

             }
             int piso =  Integer.parseInt(JOptionPane.showInputDialog("Ingrese el piso actualizado" ));
             String letraDep =  JOptionPane.showInputDialog("Ingrese su letra de departamento actualizada" );

             ph.setPiso(piso);
             ph.setLetraDep(letraDep);



         }


         if (propiedad instanceof Terreno){
                Terreno terreno = (Terreno)propiedad;
             String opt =  JOptionPane.showInputDialog("Está en construcción? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 terreno.setEnConstruccion(true);

             } else {
                 terreno.setEnConstruccion(false);

             }

         }

         if (propiedad instanceof Casa){
               Casa casa = (Casa)propiedad;
             String opt =  JOptionPane.showInputDialog("Incluye patio? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 casa.setIncluyePatio(true);

             } else {
                casa.setIncluyePatio(false);

             }



         }

         if (propiedad instanceof Quinta){
               Quinta quinta = (Quinta)propiedad;
             String opt =  JOptionPane.showInputDialog("Incluye piscina? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 quinta.setIncluyePiscina(true);

             } else {
                quinta.setIncluyePiscina(false);

             }




         }




        JOptionPane.showMessageDialog(null,"Propiedad actualizada correctamente!");



    } else {


        JOptionPane.showMessageDialog(null,"No ha sido encontrada la propiedad");





    }

   
   
   
       
       
       
       
       
   }
       
    public void editarPersona(int dni){
       Persona persona = buscarpersona(dni);
       
       
       if (persona != null){
       String nombre = JOptionPane.showInputDialog("Ingrese su nombre actualizado");
       String apellido = JOptionPane.showInputDialog("Ingrese su apellido actualizado");
       int telefono = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su telefono actualizado"));
       String email = JOptionPane.showInputDialog("Ingrese su email actualizado");
       
       persona.setNombre(nombre);
       persona.setApellido(apellido);
       persona.setTelefono(telefono);
       persona.setEmail(email);
           
           
       if (persona instanceof Cliente){
           Cliente cliente = (Cliente)persona;
           String opt =  JOptionPane.showInputDialog("Tiene Recibo de sueldo? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 cliente.setReciboSueldo(true);

             } else {
                cliente.setReciboSueldo(false);

             }
             opt =  JOptionPane.showInputDialog("Tiene mascotas? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 cliente.setMascotas(true);

             } else {
                cliente.setMascotas(false);

             }
             opt =  JOptionPane.showInputDialog("Tiene hijos? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                 cliente.setHijos(true);

             } else {
                cliente.setHijos(false);

             }
           
           
           
       }
               
           if (persona instanceof Agente){
               Agente agente = (Agente)persona;
               double puntuacion = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su puntuación actualizada"));
               
               
           }    
           
           JOptionPane.showMessageDialog(null, "Persona editada correctamente!");
       }
       else {
            JOptionPane.showMessageDialog(null, "Persona no existe / no fue encontrada");
       }
    
  }
   
    public void mostrarRemax(){
        
        for (Persona persona : personas){
            persona.mostrarDatos();
        }
        
        for (Propiedad propiedad : propiedades){
            propiedad.mostrarPropiedad();
            
            
            
        }
        
        for (Operacion operacion : operaciones){
            operacion.mostrarOperaciones();
            
        }
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
