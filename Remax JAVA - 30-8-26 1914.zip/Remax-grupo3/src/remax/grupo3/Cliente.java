
package remax.grupo3;


import javax.swing.JOptionPane;
public class Cliente extends Persona {
    
    private boolean reciboSueldo;
    private boolean mascotas;
    private boolean hijos;

    public Cliente(boolean reciboSueldo, boolean mascotas, boolean hijos, String nombre, String apellido, int dni, int telefono, String email) {
        super(nombre, apellido, dni, telefono, email);
        this.reciboSueldo = reciboSueldo;
        this.mascotas = mascotas;
        this.hijos = hijos;
    }



    public boolean isReciboSueldo() {
        return reciboSueldo;
    }

    public void setReciboSueldo(boolean reciboSueldo) {
        this.reciboSueldo = reciboSueldo;
    }

    public boolean isMascotas() {
        return mascotas;
    }

    public void setMascotas(boolean mascotas) {
        this.mascotas = mascotas;
    }

    public boolean isHijos() {
        return hijos;
    }

    public void setHijos(boolean hijos) {
        this.hijos = hijos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public void  mostrarDatos(){
        
        JOptionPane.showMessageDialog(null,"Tiene recibo de sueldo?: "+ isReciboSueldo());
        JOptionPane.showMessageDialog(null,"Tiene mascotas?: "+ isMascotas());
        JOptionPane.showMessageDialog(null,"Tiene hijos?: "+ isHijos());
        JOptionPane.showMessageDialog(null,"Nombre: "+ getNombre());
        JOptionPane.showMessageDialog(null,"Apellido: "+ getApellido());
        JOptionPane.showMessageDialog(null,"DNI: "+ getDni());
        JOptionPane.showMessageDialog(null,"Telefono: "+ getTelefono());
        JOptionPane.showMessageDialog(null,"Email: "+ getEmail());
    }   
}


