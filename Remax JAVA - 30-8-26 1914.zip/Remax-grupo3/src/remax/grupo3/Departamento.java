
package remax.grupo3;



import javax.swing.JOptionPane;

public class Departamento extends Propiedad {
    int piso;
    String LetraDep;

    public Departamento(int piso, String LetraDep, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales) {
        super(Ubicacion, Direccion, precio, Descripcion, MetrosCuadrados, Ambiente, CantBaños, Antiguedad, reseña, ExpensasMensuales);
        this.piso = piso;
        this.LetraDep = LetraDep;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public String getLetraDep() {
        return LetraDep;
    }

    public void setLetraDep(String LetraDep) {
        this.LetraDep = LetraDep;
    }

    public String getUbicacion() {
        return Ubicacion;
    }

    public void setUbicacion(String Ubicacion) {
        this.Ubicacion = Ubicacion;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public double getMetrosCuadrados() {
        return MetrosCuadrados;
    }

    public void setMetrosCuadrados(double MetrosCuadrados) {
        this.MetrosCuadrados = MetrosCuadrados;
    }

    public int getAmbiente() {
        return Ambiente;
    }

    public void setAmbiente(int Ambiente) {
        this.Ambiente = Ambiente;
    }

    public int getCantBaños() {
        return CantBaños;
    }

    public void setCantBaños(int CantBaños) {
        this.CantBaños = CantBaños;
    }

    public int getAntiguedad() {
        return Antiguedad;
    }

    public void setAntiguedad(int Antiguedad) {
        this.Antiguedad = Antiguedad;
    }

    public int getReseña() {
        return reseña;
    }

    public void setReseña(int reseña) {
        this.reseña = reseña;
    }

    public int getExpensasMensuales() {
        return ExpensasMensuales;
    }

    public void setExpensasMensuales(int ExpensasMensuales) {
        this.ExpensasMensuales = ExpensasMensuales;
    }
    @Override
    public void mostrarPropiedad(){
        JOptionPane.showMessageDialog(null,"ubicacion"+Ubicacion+
        "\ndireccion"+Direccion+
        "\nprecio"+precio+
        "\ndescripcion"+Descripcion+
        "\nmetros cuadrados"+MetrosCuadrados+
        "\nambientes"+Ambiente+
        "\ncantidad de baños"+CantBaños+
        "\nantiguedad"+Antiguedad+
        "\nreseña"+reseña+
        "\nexpensasmensuales"+ExpensasMensuales+
        "\npiso"+piso+
        "\nletra del departamento"+LetraDep  
        );         
    }
}


