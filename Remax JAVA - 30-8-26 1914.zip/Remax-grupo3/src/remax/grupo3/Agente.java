package remax.grupo3;

  import javax.swing.JOptionPane;
public class Agente extends Persona{
    
    private double puntuacionUsuario;

    public Agente(double puntuacionUsuario, String nombre, String apellido, int dni, int telefono, String email) {
        super(nombre, apellido, dni, telefono, email);
        this.puntuacionUsuario = puntuacionUsuario;
    }

    
    public double getPuntuacionUsuario() {
        return puntuacionUsuario;
    }

    public void setPuntuacionUsuario(double puntuacionUsuario) {
        this.puntuacionUsuario = puntuacionUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    @Override
    public void mostrarDatos(){
        
        JOptionPane.showMessageDialog(null,"Puntuacion de usuario: "+ getPuntuacionUsuario());
        JOptionPane.showMessageDialog(null,"Nombre: "+ getNombre());
        JOptionPane.showMessageDialog(null,"Apellido: "+ getApellido());
        JOptionPane.showMessageDialog(null,"DNI: "+ getDni());
        JOptionPane.showMessageDialog(null,"Telefono: "+ getTelefono());
        JOptionPane.showMessageDialog(null,"Email: "+ getEmail());
    }
    
}



    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

