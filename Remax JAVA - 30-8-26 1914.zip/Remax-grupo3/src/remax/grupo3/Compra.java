
package remax.grupo3;

import javax.swing.JOptionPane;
public class Compra extends Operacion {
    
    private String fecha_compra;

    public Compra(String fecha_compra, Propiedad propiedad, Cliente cliente, Agente agente) {
        super(propiedad, cliente, agente);
        this.fecha_compra = fecha_compra;
    }

  

    public String getFecha_compra() {
        return fecha_compra;
    }

    public void setFecha_compra(String fecha_compra) {
        this.fecha_compra = fecha_compra;
    }
    
    @Override
    
    public void mostrarOperaciones(){
        JOptionPane.showMessageDialog(null,"Propiedad" + getPropiedad()+",\n Cliente" + getCliente() +"\n Agente" + getAgente()+"\n Fecha de compra" + getFecha_compra());

        
    }
}

