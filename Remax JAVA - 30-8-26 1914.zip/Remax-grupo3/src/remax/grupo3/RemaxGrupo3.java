
package remax.grupo3;

import javax.swing.JOptionPane;

public class RemaxGrupo3 {

   
    public static void main(String[] args) {
    
        
        Remax remax = new Remax("REMAX Platino III", "Av. Federico Lacroze 2827");
        
        
        int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de clientes: "));  
        
        for (int i = 0; i < n; i++) {
            String nombre = JOptionPane.showInputDialog("Ingrese su nombre");
            String apellido = JOptionPane.showInputDialog("Ingrese su apellido");
            int telefono = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su telefono "));
            int dni = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su dni"));
            String email = JOptionPane.showInputDialog("Ingrese su email");
             boolean v1 = false;
            boolean v2 = false;
            boolean v3 = false;
            String opt =  JOptionPane.showInputDialog("Tiene Recibo de sueldo? [si / no o cualquier letra]" );
           
            
            
             if (opt.equalsIgnoreCase("si")){
                  v1 = true;

             } else {
                 v1 = false;

             }
             opt =  JOptionPane.showInputDialog("Tiene mascotas? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                  v2 = true;

             } else {
                 v2 = false;
             }
             opt =  JOptionPane.showInputDialog("Tiene hijos? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                  v3 = true;

             } else {
                 v3 = false;
             }
                 Cliente cliente = new Cliente(v1,v2,v3,nombre,apellido,telefono,dni,email);
                 remax.agregarPersona(cliente);
            
             }
             
             
        n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de Agentes: "));  
        
        for (int i = 0; i < n; i++) {
            String nombre = JOptionPane.showInputDialog("Ingrese su nombre");
            String apellido = JOptionPane.showInputDialog("Ingrese su apellido");
            int telefono = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su telefono"));
            int dni = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su dni"));
            String email = JOptionPane.showInputDialog("Ingrese su email");
            Double v1 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su puntuación"));
                 Agente agente = new Agente(v1,nombre,apellido,telefono,dni,email);
                 remax.agregarPersona(agente);
            
        }

        
        
        
        
        
        n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de Departamentos: "));  
        
        for (int i = 0; i < n; i++) {
        String ubicacion = JOptionPane.showInputDialog("Ingrese su ubicacion");
        String direccion = JOptionPane.showInputDialog("Ingrese su dirección");
        int precio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su precio"));
        String descripcion = JOptionPane.showInputDialog("Ingrese su descripción");
        double m2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su tamaño en metros cuadrados"));
         int ambientes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de ambientes"));
         int baños = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su cantidad de baños"));
         int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su antiguedad"));
         int reseña = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su puntuación en promedio de reseñas"));
         int expensas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus expensas"));
         
             int piso =  Integer.parseInt(JOptionPane.showInputDialog("Ingrese el piso actualizado" ));
             String letraDep =  JOptionPane.showInputDialog("Ingrese su letra de departamento actualizada" );
         
             Departamento departamento = new Departamento(piso,letraDep,ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas);
         
         remax.agregarPropiedad(departamento);
        }
        
           
        n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de Oficinas: "));  
        
        for (int i = 0; i < n; i++) {
        String ubicacion = JOptionPane.showInputDialog("Ingrese su ubicacion");
        String direccion = JOptionPane.showInputDialog("Ingrese su dirección");
        int precio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su precio"));
        String descripcion = JOptionPane.showInputDialog("Ingrese su descripción");
        double m2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su tamaño en metros cuadrados"));
         int ambientes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de ambientes"));
         int baños = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su cantidad de baños"));
         int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su antiguedad"));
         int reseña = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su puntuación en promedio de reseñas"));
         int expensas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus expensas"));
         
         boolean v1 = false;
        String opt =  JOptionPane.showInputDialog("Incluye muebles? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                v1 = true;

             } else {
                 v1 = false;

             }
         
             Oficina oficina = new Oficina(v1,ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas);
         
         remax.agregarPropiedad(oficina);
        }
        
        
          n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de PHs: "));  
        
        for (int i = 0; i < n; i++) {
      String ubicacion = JOptionPane.showInputDialog("Ingrese su ubicacion");
        String direccion = JOptionPane.showInputDialog("Ingrese su dirección");
        int precio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su precio"));
        String descripcion = JOptionPane.showInputDialog("Ingrese su descripción");
        double m2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su tamaño en metros cuadrados"));
         int ambientes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de ambientes"));
         int baños = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su cantidad de baños"));
         int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su antiguedad"));
         int reseña = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su puntuación en promedio de reseñas"));
         int expensas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus expensas"));
         
         boolean v1 = false;
         
        String opt =  JOptionPane.showInputDialog("Incluye Ventana? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                v1 = true;

             } else {
                 v1 = false;

             }
         
               int piso =  Integer.parseInt(JOptionPane.showInputDialog("Ingrese el piso actualizado" ));
             String letraDep =  JOptionPane.showInputDialog("Ingrese su letra de departamento actualizada" );
             
             PH ph = new PH(v1, piso, letraDep,ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas);
         
         remax.agregarPropiedad(ph);      
        }
        
        
         n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de Casas: "));  
        
        for (int i = 0; i < n; i++) {
        String ubicacion = JOptionPane.showInputDialog("Ingrese su ubicacion");
        String direccion = JOptionPane.showInputDialog("Ingrese su dirección");
        int precio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su precio"));
        String descripcion = JOptionPane.showInputDialog("Ingrese su descripción");
        double m2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su tamaño en metros cuadrados"));
         int ambientes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de ambientes"));
         int baños = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su cantidad de baños"));
         int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su antiguedad"));
         int reseña = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su puntuación en promedio de reseñas"));
         int expensas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus expensas"));
         
         boolean v1 = false;
         
        String opt =  JOptionPane.showInputDialog("Incluye Patio? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                v1 = true;

             } else {
                 v1 = false;

             }
         
             
              Casa casa = new Casa(v1, ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas);
         
         remax.agregarPropiedad(casa);      
        }
        
         n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de Terrenos: "));  
        
        for (int i = 0; i < n; i++) {
        String ubicacion = JOptionPane.showInputDialog("Ingrese su ubicacion");
        String direccion = JOptionPane.showInputDialog("Ingrese su dirección");
        int precio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su precio"));
        String descripcion = JOptionPane.showInputDialog("Ingrese su descripción");
        double m2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su tamaño en metros cuadrados"));
         int ambientes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de ambientes"));
         int baños = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su cantidad de baños"));
         int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su antiguedad"));
         int reseña = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su puntuación en promedio de reseñas"));
         int expensas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus expensas"));
         
         boolean v1 = false;
         
        String opt =  JOptionPane.showInputDialog("Está en construcción? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                v1 = true;

             } else {
                 v1 = false;

             }
         
             
              Terreno terreno = new Terreno(v1, ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas);
         
         remax.agregarPropiedad(terreno);      
        }
        
              n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de Quintas: "));  
        
        for (int i = 0; i < n; i++) {
        String ubicacion = JOptionPane.showInputDialog("Ingrese su ubicacion");
        String direccion = JOptionPane.showInputDialog("Ingrese su dirección");
        int precio = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su precio"));
        String descripcion = JOptionPane.showInputDialog("Ingrese su descripción");
        double m2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su tamaño en metros cuadrados"));
         int ambientes = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de ambientes"));
         int baños = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su cantidad de baños"));
         int antiguedad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su antiguedad"));
         int reseña = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su puntuación en promedio de reseñas"));
         int expensas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus expensas"));
         
         boolean v1 = false;
         
        String opt =  JOptionPane.showInputDialog("Incluye Piscina? [si / no o cualquier letra]" );
             if (opt.equalsIgnoreCase("si")){
                v1 = true;

             } else {
                 v1 = false;

             }
         
             
              Quinta quinta = new Quinta(v1, ubicacion,direccion,precio,descripcion,m2,ambientes,baños,antiguedad,reseña,expensas);
         
         remax.agregarPropiedad(quinta);      
        }
        
        
        
        
        n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de compras: "));  
        for (int i = 0; i < n; i++) {
            
            int nx = 0; //numero x contador
           
            Cliente cli = null;
            Agente age =  null;
            Propiedad elegida = null;
            
            
            // 0 = si ... 1 = no ... 3 = cancel ... etc
            for (Propiedad propiedad : remax.getPropiedades()){
                propiedad.mostrarPropiedad();
                int opt = JOptionPane.showConfirmDialog(null,
                                "Propiedad n°" + nx , "Es la propiedad que va a elegir?",
                                 JOptionPane.YES_NO_OPTION);
       
                if (opt == 0){
                    elegida = propiedad;
                    break;
                    
                }
                nx = nx +1;
            }
            
            
            
            nx = 0;
            
             for (Persona persona : remax.getPersonas()){
                if (persona instanceof Cliente){
                persona.mostrarDatos();
                int opt = JOptionPane.showConfirmDialog(null,
                                 "Cliente n°" + nx , "Es el cliente que va a elegir?",
                                 JOptionPane.YES_NO_OPTION);
       
                if (opt == 0){
                    cli = (Cliente)persona;
                    break;
                    
                }
                nx = nx +1;
                
                
                }
                
                
                
                
            }
            
            
              
            nx = 0;
            
             for (Persona persona : remax.getPersonas()){
                if (persona instanceof Agente){
                persona.mostrarDatos();
                int opt = JOptionPane.showConfirmDialog(null,
                                 "Agente n°" + nx , "Es el agente que va a elegir?",
                                 JOptionPane.YES_NO_OPTION);
       
                if (opt == 0){
                    age = (Agente)persona;
                    break;
                    
                }
                nx = nx +1;
                
                
                }
                
            String fecha_compra = JOptionPane.showInputDialog("Ingrese la fecha de la compra");
                
                Compra compra = new Compra(fecha_compra, elegida, cli, age);
                remax.agregarOperacion(compra);
                
            }
            
            
             
             
             
             
             
             
             
            
            
            
            
        }
        
        
        
        
        n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de alquileres: "));  
        for (int i = 0; i < n; i++) {
            
            int nx = 0; //numero x contador
           
            Cliente cli = null;
            Agente age =  null;
            Propiedad elegida = null;
            
            
            // 0 = si ... 1 = no ... 3 = cancel ... etc
            for (Propiedad propiedad : remax.getPropiedades()){
                propiedad.mostrarPropiedad();
                int opt = JOptionPane.showConfirmDialog(null,
                                "Propiedad n°" + nx , "Es la propiedad que va a elegir?",
                                 JOptionPane.YES_NO_OPTION);
       
                if (opt == 0){
                    elegida = propiedad;
                    break;
                    
                }
                nx = nx +1;
            }
            
            
            
            nx = 0;
            
             for (Persona persona : remax.getPersonas()){
                if (persona instanceof Cliente){
                persona.mostrarDatos();
                int opt = JOptionPane.showConfirmDialog(null,
                                 "Cliente n°" + nx , "Es el cliente que va a elegir?",
                                 JOptionPane.YES_NO_OPTION);
       
                if (opt == 0){
                    cli = (Cliente)persona;
                    break;
                    
                }
                nx = nx +1;
                
                
                }
                
                
                
                
            }
            
            
              
            nx = 0;
            
             for (Persona persona : remax.getPersonas()){
                if (persona instanceof Agente){
                persona.mostrarDatos();
                int opt = JOptionPane.showConfirmDialog(null,
                                 "Agente n°" + nx , "Es el agente que va a elegir?",
                                 JOptionPane.YES_NO_OPTION);
       
                if (opt == 0){
                    age = (Agente)persona;
                    break;
                    
                }
                nx = nx +1;
                
                
                }
                
            String fecha_inicio = JOptionPane.showInputDialog("Ingrese la fecha de la compra");
                 
             int plazo_meses_alquiler = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de meses del plazo del alquiler"));
                Alquiler alquiler = new Alquiler(fecha_inicio, plazo_meses_alquiler, elegida, cli, age);
                
                remax.agregarOperacion(alquiler);
                
            }
            
            
             
             
             
             
             
             
             
            
            
            
            
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        remax.mostrarRemax();
        
        int dnii = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el dni de la persona que quiera editar"));
        remax.editarPersona(dnii);
        
        String direccion = JOptionPane.showInputDialog("Ingrese la direccion de la propiedad que quiera editar");
        remax.editarPropiedad(direccion);
        
        remax.mostrarRemax();
        
        
        
    }
    
}
