
package remax.grupo3;

import javax.swing.JOptionPane;
public class PH extends Propiedad {
    private boolean incluyeVentana;
    private int piso;
    private String letraDep;

    public PH(boolean incluyeVentana, int piso, String letraDep, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales) {
        super(Ubicacion, Direccion, precio, Descripcion, MetrosCuadrados, Ambiente, CantBaños, Antiguedad, reseña, ExpensasMensuales);
        this.incluyeVentana = incluyeVentana;
        this.piso = piso;
        this.letraDep = letraDep;
    }

    public boolean isIncluyeVentana() {
        return incluyeVentana;
    }

    public void setIncluyeVentana(boolean incluyeVentana) {
        this.incluyeVentana = incluyeVentana;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public String getLetraDep() {
        return letraDep;
    }

    public void setLetraDep(String letraDep) {
        this.letraDep = letraDep;
    }

    
    @Override
    public void mostrarPropiedad(){
    JOptionPane.showMessageDialog(null, "ubicacion"+Ubicacion+
    "\ndireccion"+Direccion+
    "\nprecio"+precio+
    "\ndescripcion"+Descripcion+
    "\nmetros cuadrados"+MetrosCuadrados+
    "\nambientes"+Ambiente+
    "\ncantidad de baños"+CantBaños+
    "\nantiguedad"+Antiguedad+
    "\nreseña"+reseña+
    "\nexpensasmensuales"+ExpensasMensuales+
    "\nincluyeVentana" + incluyeVentana + 
    "\npiso" + piso+ 
    "\netraDep" + letraDep );
    }
}

