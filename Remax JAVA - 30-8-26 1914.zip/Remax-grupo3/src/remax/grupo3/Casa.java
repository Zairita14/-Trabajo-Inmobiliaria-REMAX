
package remax.grupo3;

import javax.swing.JOptionPane;
public class Casa extends Propiedad {
    private boolean incluyePatio;

    public Casa(boolean incluyePatio, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales) {
        super(Ubicacion, Direccion, precio, Descripcion, MetrosCuadrados, Ambiente, CantBaños, Antiguedad, reseña, ExpensasMensuales);
        this.incluyePatio = incluyePatio;
    }

    public boolean isIncluyePatio() {
        return incluyePatio;
    }

    public void setIncluyePatio(boolean incluyePatio) {
        this.incluyePatio = incluyePatio;
    }
    
    
    @Override
    public void mostrarPropiedad(){
    JOptionPane.showMessageDialog(null, "ubicacion"+Ubicacion+
    "\ndireccion"+Direccion+
    "\nprecio"+precio+
    "\ndescripcion"+Descripcion+
    "\nmetros cuadrados"+MetrosCuadrados+
    "\nambientes"+Ambiente+
    "\ncantidad de baños"+CantBaños+
    "\nantiguedad"+Antiguedad+
    "\nreseña"+reseña+
    "\nexpensasmensuales"+ExpensasMensuales+
    "\nincluyePatio" + incluyePatio );
    } 
}

