
package remax.grupo3;


import javax.swing.JOptionPane;

public class Terreno extends Propiedad {
    private boolean enConstruccion;

    public Terreno(boolean enConstruccion, String Ubicacion, String Direccion, int precio, String Descripcion, double MetrosCuadrados, int Ambiente, int CantBaños, int Antiguedad, int reseña, int ExpensasMensuales) {
        super(Ubicacion, Direccion, precio, Descripcion, MetrosCuadrados, Ambiente, CantBaños, Antiguedad, reseña, ExpensasMensuales);
        this.enConstruccion = enConstruccion;
    }

    public boolean isEnConstruccion() {
        return enConstruccion;
    }

    public void setEnConstruccion(boolean enConstruccion) {
        this.enConstruccion = enConstruccion;
    }

  @Override
    public void mostrarPropiedad(){
        JOptionPane.showMessageDialog(null, "Terreno: " + "\n Ubicacion: "+Ubicacion+
        "\n Direccion: "+ Direccion+
        "\n Precio: "+precio+
        "\n Descripcion: "+Descripcion+
        "\n Metros cuadrados: "+MetrosCuadrados+
        "\n Ambientes: "+Ambiente+
        "\n Cantidad de baños: "+CantBaños+
        "\n Antiguedad: "+Antiguedad+
        "\n Reseña:"+reseña+
        "\n Expensas Mensuales: "+ ExpensasMensuales+
 "\n Está en construcción?: " + enConstruccion
        );         
    }
}


