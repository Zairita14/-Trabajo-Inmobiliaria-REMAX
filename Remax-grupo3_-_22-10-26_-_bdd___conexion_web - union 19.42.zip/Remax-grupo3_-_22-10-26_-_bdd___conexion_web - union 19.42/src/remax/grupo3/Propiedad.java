package remax.grupo3;

public class Propiedad {
    private int id_propiedad;
    private String tipoPropiedad;
    private String ubicacion;
    private String direccion;
    private int precio;
    private String descripcion;
    private int metrosCuadrados;
    private int antiguedad;
    private int reseña;
    private int expensasMensuales;
    private int piso;
    private String letraDep;
    private boolean enConstruccion;
    private int id_propietario;

    public Propiedad(String tipoPropiedad, String ubicacion, String direccion, int precio, String descripcion, int metrosCuadrados, int antiguedad, int reseña, int expensasMensuales, int piso, String letraDep, boolean enConstruccion, int id_propietario) {
        this.tipoPropiedad = tipoPropiedad;
        this.ubicacion = ubicacion;
        this.direccion = direccion;
        this.precio = precio;
        this.descripcion = descripcion;
        this.metrosCuadrados = metrosCuadrados;
        this.antiguedad = antiguedad;
        this.reseña = reseña;
        this.expensasMensuales = expensasMensuales;
        this.piso = piso;
        this.letraDep = letraDep;
        this.enConstruccion = enConstruccion;
        this.id_propietario = id_propietario;
    }

    public int getId_propiedad() {
        return id_propiedad;
    }

    public void setId_propiedad(int id_propiedad) {
        this.id_propiedad = id_propiedad;
    }

    public String getTipoPropiedad() {
        return tipoPropiedad;
    }

    public void setTipoPropiedad(String tipoPropiedad) {
        this.tipoPropiedad = tipoPropiedad;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getMetrosCuadrados() {
        return metrosCuadrados;
    }

    public void setMetrosCuadrados(int metrosCuadrados) {
        this.metrosCuadrados = metrosCuadrados;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }

    public int getReseña() {
        return reseña;
    }

    public void setReseña(int reseña) {
        this.reseña = reseña;
    }

    public int getExpensasMensuales() {
        return expensasMensuales;
    }

    public void setExpensasMensuales(int expensasMensuales) {
        this.expensasMensuales = expensasMensuales;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public String getLetraDep() {
        return letraDep;
    }

    public void setLetraDep(String letraDep) {
        this.letraDep = letraDep;
    }

    public boolean isEnConstruccion() {
        return enConstruccion;
    }

    public void setEnConstruccion(boolean enConstruccion) {
        this.enConstruccion = enConstruccion;
    }

    public int getId_propietario() {
        return id_propietario;
    }

    public void setId_propietario(int id_propietario) {
        this.id_propietario = id_propietario;
    }

    


    
    
}
