/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remax.grupo3;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class PropietarioDAO {
    public void insertar(Propietario propietario){
    String consulta_sql = "INSERT INTO Propietarios  values (default, ?,?,?,?,?)";
    
    try{
    Connection conexion= Conexion.conectar();
     PreparedStatement sentencia_sql= conexion.prepareStatement(consulta_sql);
     
     sentencia_sql.setString(1,propietario.getNombre());
     sentencia_sql.setString(2,propietario.getApellido());
     sentencia_sql.setInt(3,propietario.getDni());
     sentencia_sql.setInt(4,propietario.getTelefono());
     sentencia_sql.setString(5,propietario.getCorreo());
     
    sentencia_sql.executeUpdate();
            System.out.println("PROPIETARIOS GUARDADO EXSITOSAMENTE :D");
} catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Propietario insertado exitosamente");
}
    
    
     public ArrayList<Propietario> listar() {
       ArrayList<Propietario>lista_propietarios = new ArrayList<>();
       String consulta_sql ="SELECT * FROM Propietarios";
       try{
           Connection conexion = Conexion.conectar();
           PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
           //sentencia_sql.setInt(1,dni_buscado);
           ResultSet resultado= sentencia_sql.executeQuery();
           while (resultado.next()){
               Propietario propietario = new Propietario("a","a",1,1,"a");
               propietario.setId_propietario(resultado.getInt("id_propietario"));
               propietario.setNombre(resultado.getString("nombre"));
               propietario.setApellido(resultado.getString("apellido"));
               propietario.setDni(resultado.getInt("dni"));
               propietario.setTelefono(resultado.getInt("telefono"));
               propietario.setCorreo(resultado.getString("correo"));
                     
               lista_propietarios.add(propietario);
               
           }
           
       }catch (SQLException ex){
           System.out.println("ERROR: " + ex.getMessage());
       }
       return lista_propietarios;
    }
    
    
    public void eliminar(int id_propietario){
        String consulta_sql = "DELETE FROM propietarios WHERE id_propietario = ?";
       
        try {
            
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, id_propietario);
            sentencia_sql.executeUpdate();
           
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Propietario eliminado exitosamente");
    }
    public void actualizar(Propietario propietario){
        String consulta_sql = "UPDATE propietarios SET nombre = ?, apellido = ?, dni = ?, telefono = ?, correo = ? WHERE id_propietario = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            
            sentencia_sql.setString(1,propietario.getNombre());
            sentencia_sql.setString(2,propietario.getApellido());
            sentencia_sql.setInt(3, propietario.getDni());
            sentencia_sql.setInt(4, propietario.getTelefono());
            sentencia_sql.setString(5,propietario.getCorreo());
            sentencia_sql.setInt(6,propietario.getId_propietario());
            sentencia_sql.executeUpdate();
            
            System.out.println("Datos actualizados exitosamente");
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           return;
        }
        JOptionPane.showMessageDialog(null,"Propietario actualizado exitosamente");
        
        
    }
    
    public ArrayList<Propietario> buscar(int dni_buscado){
        ArrayList<Propietario> propietarios = new ArrayList<>();
        String consulta_sql = "SELECT * FROM propietarios WHERE dni = ?";
        
        try{
            Connection conexion = Conexion.conectar();
            PreparedStatement sentencia_sql = conexion.prepareStatement(consulta_sql);
            sentencia_sql.setInt(1, dni_buscado);
            ResultSet resultado_sql = sentencia_sql.executeQuery();
            
            while(resultado_sql.next()){
                Propietario propietario = new Propietario("","",1,1,"");
                propietario.setId_propietario(resultado_sql.getInt("id_propietario"));
                propietario.setNombre(resultado_sql.getString("nombre"));
                propietario.setApellido(resultado_sql.getString("apellido"));
                propietario.setDni(resultado_sql.getInt("dni"));
                propietario.setTelefono(resultado_sql.getInt("telefono"));
                propietario.setCorreo(resultado_sql.getString("correo"));
                
                
                propietarios.add(propietario);
            }
        }catch(SQLException ex){
            
            JOptionPane.showMessageDialog(null,"ERROR: " + ex.getMessage());
           
        }
    
        return propietarios;

    }
}