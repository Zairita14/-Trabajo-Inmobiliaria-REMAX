
package remax.grupo3;

public class Operacion {
    private int id_operacion;
    private int id_propiedad;
    private int id_agente;
    private int id_cliente;
    private String fecha_operacion;
    private String tipoOperacion;
    private String fecha_inicio;
    private int plazo_meses;
    private String fecha_compra;

    public Operacion(int id_propiedad, int id_agente, int id_cliente, String fecha_operacion, String tipoOperacion, String fecha_inicio, int plazo_meses, String fecha_compra) {
        this.id_propiedad = id_propiedad;
        this.id_agente = id_agente;
        this.id_cliente = id_cliente;
        this.fecha_operacion = fecha_operacion;
        this.tipoOperacion = tipoOperacion;
        this.fecha_inicio = fecha_inicio;
        this.plazo_meses = plazo_meses;
        this.fecha_compra = fecha_compra;
    }

    public int getId_operacion() {
        return id_operacion;
    }

    public void setId_operacion(int id_operacion) {
        this.id_operacion = id_operacion;
    }

    public int getId_propiedad() {
        return id_propiedad;
    }

    public void setId_propiedad(int id_propiedad) {
        this.id_propiedad = id_propiedad;
    }

    public int getId_agente() {
        return id_agente;
    }

    public void setId_agente(int id_agente) {
        this.id_agente = id_agente;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getFecha_operacion() {
        return fecha_operacion;
    }

    public void setFecha_operacion(String fecha_operacion) {
        this.fecha_operacion = fecha_operacion;
    }

    public String getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(String tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public int getPlazo_meses() {
        return plazo_meses;
    }

    public void setPlazo_meses(int plazo_meses) {
        this.plazo_meses = plazo_meses;
    }

    public String getFecha_compra() {
        return fecha_compra;
    }

    public void setFecha_compra(String fecha_compra) {
        this.fecha_compra = fecha_compra;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
